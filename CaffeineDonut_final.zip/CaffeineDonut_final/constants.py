import pygame

# Screen dimensions (GDD Section 2)
WIDTH = 800
HEIGHT = 600

# Player properties (GDD Section 1)
PLAYER_SPEED = 5
PLAYER_WIDTH = 20
PLAYER_HEIGHT = 20
PLAYER_COLOR = (255, 255, 255)  # WHITE

# Door properties (GDD Section 4)
DOOR_WIDTH = 50 # Diameter of the half-circle
DOOR_COLOR = (192, 192, 192)  # GREY

# Object properties (GDD Sections 2, 5)
RUBBISH_RADIUS = 10
INTERN_SPEED = 5
INTERN_RADIUS = 15
SECRETARY_RADIUS = 15
BOSS_RADIUS = 30
TABLE_WIDTH = 60
TABLE_HEIGHT = 30
CHAIR_RADIUS = 10 # GDD specifies chairs are circular
DATA_CENTER_RECT_WIDTH = 70 # Made larger and vertical
DATA_CENTER_RECT_HEIGHT = 120 # Made larger and vertical
MEETING_TABLE_WIDTH = 200 # Larger table for meeting room
MEETING_TABLE_HEIGHT = 100

# Game states (GDD Section 6)
GAME_STATE_START = 0
GAME_STATE_PLAY = 1

# Timers (frames, GDD Section 1)
MESSAGE_DURATION = 120  # 2 seconds at 60 FPS
PASSWORD_DURATION = 3600
COOLDOWN_DURATION = 60

# Passwords and requirements (GDD Section 5)
ROOM3_PASSWORD = "cip"
ROOM4_PASSWORD = "adela"
ROOM8_PASSWORD = "b"
COFFEE_REQUIRED = 10 # For pantry room

# Room instructions/hints (GDD Section 1)
ROOM_INSTRUCTIONS = {
    "lobby": "Welcome to your worst nightmare. Find the door out. Fast.",
    "coding_cubicle": "This is where dreams come to die. Find the key to escape.",
    "data_center": "The hum of servers is the sound of your impending doom. Find the password.",
    "meeting_room": "Where productivity goes to waste. Find the monitor to proceed.",
    "server_room": "Beware the intern. He's always breaking things... and careers.",
    "pantry": "Survival requires sustenance. Collect coffee to survive.",
    "secretary_room": "Choose the right door to face the boss.",
    "boss_room": "Answer the boss's question to escape."
}

# Frame rate (GDD Section 6)
FPS = 60

# Font Sizes (GDD Section 2)
LARGE_FONT_SIZE = 25 # Reduced by 5
MEDIUM_FONT_SIZE = 17 # Reduced by 5
SMALL_FONT_SIZE = 13 # Reduced by 5
TINY_FONT_SIZE = 8 # Increased to 8 for inventory prompt readability

# Colors (GDD Section 3)
WHITE = (255, 255, 255)  # Player, text
SKY_BLUE_GREY = (135, 206, 235) # Walls color (new)
GREY = (192, 192, 192)  # Doors color, Generic Rubbish (Room 2)
YELLOW = (255, 255, 0)  # Interaction blink
EARTHY_BROWN = (139, 69, 19)  # Tables
DEEP_TEAL = (0, 128, 128)  # Chairs
CREAM_WHITE = (255, 253, 208)  # Half donut, Pantry structure
SLIME_GREEN = (85, 107, 47)  # Moldy coffee cup, all uncollected rubbish in Room 2
GOLD_YELLOW = (255, 215, 0)  # Key (flash color, not initial color)
BRIGHT_ORANGE = (255, 140, 0)  # Data center obstacles
DARK_PURPLE = (75, 0, 130)  # Broken mice
STEEL_BLUE_GREY = (70, 80, 90)  # Meeting room table
DEEP_INDIGO = (75, 0, 130)  # Meeting room monitor (off)
LIGHT_BLUE_SCREEN = (173, 216, 230)  # Meeting room monitor (on, light blue) - Renamed for clarity
IRON_GREY = (90, 90, 90)  # Server room obstacles
ESPRESSO_BROWN = (60, 40, 20)  # Pantry coffee machines
PALE_LAVENDER = (230, 230, 250)  # Secretary table
MUTED_CYAN = (0, 139, 139)  # Secretary chair
VIBRANT_RED = (255, 0, 0)  # Intern, Secretary NPC
BLOOD_RED = (139, 0, 0)  # The Boss
SHARP_PINK = (255, 105, 180) # Lobby background
DARK_YELLOW = (255, 204, 0) # Coding cubicle background
SHARP_GREEN = (0, 200, 0) # Data center background
COOL_GREY = (150, 160, 170) # Meeting room background
CHARCOAL_GREY = (50, 50, 50) # Server room background
ORANGE = (255, 165, 0) # Pantry background
LIGHT_BLUE = (173, 216, 230) # Secretary room background
BLACK = (0, 0, 0) # Boss room background, conversation box, start screen
