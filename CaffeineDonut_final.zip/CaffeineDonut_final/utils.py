import pygame
# Import specific constants needed
from constants import CHARCOAL_GREY

# Note: WIDTH_GLOBAL and HEIGHT_GLOBAL are not truly global in the Python sense across modules.
# For draw_data_center, it accesses pygame.display.get_surface().get_width() and get_height(),
# which correctly reflects the current window dimensions. This is good practice.
# Removed WIDTH_GLOBAL and HEIGHT_GLOBAL as they are unused placeholders and can be misleading.

def play_sound(sound_name: str):
    """Play a sound effect (GDD Section 3)."""
    try:
        if pygame.mixer.get_init():
            sound = pygame.mixer.Sound(f"assets/{sound_name}.mp3")
            sound.play()
        else:
            print(f"Pygame mixer not initialized. Cannot play sound: {sound_name}.mp3")
    except pygame.error as e:
        print(f"Pygame sound error for {sound_name}.mp3: {e}")
    except FileNotFoundError:
        print(f"Sound file not found: assets/{sound_name}.mp3")
    except Exception as e:
        print(f"An unexpected error occurred while playing sound {sound_name}.mp3: {e}")

def play_background_music():
    """Play background music in a loop (GDD Section 3)."""
    try:
        if pygame.mixer.get_init():
            pygame.mixer.music.load("assets/background_music.mp3")
            pygame.mixer.music.set_volume(0.4) # Adjust volume as needed
            pygame.mixer.music.play(-1) # -1 means loop indefinitely
        else:
            print("Pygame mixer not initialized. Cannot play background music.")
    except pygame.error as e:
        print(f"Pygame music error: {e}")
    except FileNotFoundError:
        print("Background music file not found: assets/background_music.mp3")
    except Exception as e:
        print(f"An unexpected error occurred while playing background music: {e}")

def stop_background_music():
    """Stop background music (GDD Section 3)."""
    try:
        if pygame.mixer.get_init() and pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()
    except pygame.error as e:
        print(f"Pygame music error during stop: {e}")
    except Exception as e:
        print(f"An unexpected error occurred while stopping background music: {e}")

def draw_data_center(screen):
    """Draw grid pattern for data_center room (GDD Section 2)."""
    # This function implicitly uses the current screen dimensions via pygame.display.get_surface()
    try:
        # Draw a subtle grid pattern using CHARCOAL_GREY
        for x in range(0, screen.get_width(), 40): # Use current screen width
            # Adjust range for canvas height, which is total height minus conversation box height (110)
            for y in range(0, screen.get_height() - 110, 40):
                pygame.draw.circle(screen, CHARCOAL_GREY, (x, y), 2)
    except Exception as e:
        print(f"Error drawing data center grid: {e}")
