import pygame
import math
from typing import Tuple, List, Optional
# Import specific constants needed
from constants import (
    PLAYER_COLOR, GREY, YELLOW, EARTHY_BROWN, DEEP_TEAL, CHAIR_RADIUS,
    RUBBISH_RADIUS, GOLD_YELLOW, CREAM_WHITE, SLIME_GREEN, BRIGHT_ORANGE,
    DARK_PURPLE, STEEL_BLUE_GREY, DEEP_INDIGO, LIGHT_BLUE_SCREEN, IRON_GREY,
    ESPRESSO_BROWN, PALE_LAVENDER, MUTED_CYAN, VIBRANT_RED, BLOOD_RED,
    DOOR_COLOR, BLACK, WHITE, PLAYER_WIDTH, PLAYER_HEIGHT, DOOR_WIDTH,
    BOSS_RADIUS, INTERN_RADIUS, SECRETARY_RADIUS, SKY_BLUE_GREY, SHARP_PINK,
    PLAYER_SPEED, INTERN_SPEED, TABLE_WIDTH, TABLE_HEIGHT, DATA_CENTER_RECT_WIDTH,
    DATA_CENTER_RECT_HEIGHT, MEETING_TABLE_WIDTH, MEETING_TABLE_HEIGHT,
    GAME_STATE_START, GAME_STATE_PLAY, MESSAGE_DURATION, PASSWORD_DURATION,
    COOLDOWN_DURATION, ROOM3_PASSWORD, ROOM4_PASSWORD, ROOM8_PASSWORD, COFFEE_REQUIRED,
    ROOM_INSTRUCTIONS, FPS, LARGE_FONT_SIZE, MEDIUM_FONT_SIZE, SMALL_FONT_SIZE, TINY_FONT_SIZE
)
from utils import draw_data_center
from typing import Tuple # Import for type hinting pygame.Surface

# Initialize pygame
pygame.init()
pygame.font.init()

# Initialize fonts
FONT_PATH = "assets/pressstart2p.ttf"
try:
    LARGE_FONT = pygame.font.Font(FONT_PATH, LARGE_FONT_SIZE)
    MEDIUM_FONT = pygame.font.Font(FONT_PATH, MEDIUM_FONT_SIZE)
    SMALL_FONT = pygame.font.Font(FONT_PATH, SMALL_FONT_SIZE)
    TINY_FONT = pygame.font.Font(FONT_PATH, TINY_FONT_SIZE)
except FileNotFoundError:
    print("Custom font 'pressstart2p.ttf' not found. Using Courier New as fallback.")
    LARGE_FONT = pygame.font.SysFont("couriernew", LARGE_FONT_SIZE)
    MEDIUM_FONT = pygame.font.SysFont("couriernew", MEDIUM_FONT_SIZE)
    SMALL_FONT = pygame.font.SysFont("couriernew", SMALL_FONT_SIZE)
    TINY_FONT = pygame.font.SysFont("couriernew", TINY_FONT_SIZE)

def render_game(
    screen: pygame.Surface, # Added type hint
    current_room,
    player_x,
    player_y,
    inventory,
    rubbish_objects,
    table_sets,
    data_center_objects,
    data_center_obstacles,
    meeting_room_table,
    meeting_chairs,
    monitor_rect,
    server_rectangles,
    intern_x,
    intern_y,
    pantry_rectangles,
    pantry_circles,
    secretary_table,
    secretary_chair_center,
    secretary_x,
    secretary_y,
    # Added door-related parameters
    door_confirmation,
    nearest_door,
    door_message,
    key_message,
    key_message_timer,
    password_mode,
    password_message,
    password_input,
    password_message_timer,
    table_message,
    table_message_timer,
    monitor_message,
    monitor_timer,
    intern_message,
    object_message,
    object_message_timer,
    game_over,
    escaped,
    trap_message,
    victory_message,
    restart_confirm_window,
    room_instruction,
    room_instruction_timer,
    blink_timer,
    flash_timer,
    show_end_screen,
    monitor_on,
    show_inventory,
    inventory_prompt,
    medium_font_obj: pygame.font.Font, # Added type hint
    small_font_obj: pygame.font.Font, # Added type hint
    tiny_font_obj: pygame.font.Font, # Added type hint
    width: int, # Added type hint
    height: int # Added type hint
) -> None: # Added return type hint
    """Render the game state to the screen (GDD Sections 2–3).
    Args:
        screen: Pygame surface to render on.
        current_room: Current room object.
        player_x: Player's x-coordinate.
        player_y: Player's y-coordinate.
        inventory: List of collected items.
        rubbish_objects: List of rubbish objects in the coding cubicle.
        table_sets: List of table and chair sets in the coding cubicle.
        data_center_objects: List of collectible objects in the data center.
        data_center_obstacles: List of obstacle rectangles in the data center.
        meeting_room_table: Rectangle for the meeting room table.
        meeting_chairs: List of chair centers for the meeting room.
        monitor_rect: Rectangle for the monitor in the meeting room.
        server_rectangles: List of obstacles in the server room.
        intern_x: Intern's x-coordinate.
        intern_y: Intern's y-coordinate.
        pantry_rectangles: List of rectangles forming the pantry structure.
        pantry_circles: List of coffee machine circles in the pantry.
        secretary_table: Rectangle for the secretary's table.
        secretary_chair_center: Center coordinates of the secretary's chair.
        secretary_x: Secretary's x-coordinate.
        secretary_y: Secretary's y-coordinate.
        door_confirmation: Boolean, True if a door confirmation prompt is active.
        nearest_door: Tuple, information about the nearest door.
        door_message: Message displayed for door interaction.
        key_message: Message displayed for key-related interactions.
        key_message_timer: Timer for key messages.
        password_mode: Boolean, True if in password input mode.
        password_message: Message displayed during password input.
        password_input: Current password input string.
        password_message_timer: Timer for password messages.
        table_message: Message displayed when interacting with tables.
        table_message_timer: Timer for table messages.
        monitor_message: Message displayed when interacting with the monitor.
        monitor_timer: Timer for monitor messages.
        intern_message: Message displayed when interacting with the intern.
        object_message: Message displayed when collecting objects.
        object_message_timer: Timer for object messages.
        game_over: Boolean, True if the game is over.
        escaped: Boolean, True if the player has escaped (won).
        trap_message: Message displayed when a trap is triggered.
        victory_message: Message displayed on game victory.
        restart_confirm_window: Boolean, True if restart confirmation is shown.
        room_instruction: Instruction message for the current room.
        room_instruction_timer: Timer for room instruction messages.
        blink_timer: Timer for player blinking animation.
        flash_timer: Timer for object collection flash.
        show_end_screen: Boolean, True if the end screen is displayed.
        monitor_on: Boolean, True if the meeting room monitor is on.
        show_inventory: Boolean, True if inventory is displayed.
        inventory_prompt: Text for the inventory toggle hint.
        medium_font_obj: Pygame font object for medium text.
        small_font_obj: Pygame font object for small text.
        tiny_font_obj: Pygame font object for tiny text.
        width: int, # Added type hint
        height: int # Added type hint
    """
    try:
        screen.fill(current_room.background_color)

        # Data center grid pattern (uses global WIDTH/HEIGHT implicitly within utils)
        if current_room.name == "data_center":
            draw_data_center(screen)

        # Walls (using dynamically passed width and height)
        pygame.draw.rect(screen, SKY_BLUE_GREY, (0, 0, width, 10)) # Top wall
        pygame.draw.rect(screen, SKY_BLUE_GREY, (0, 0, 10, height - 110)) # Left wall
        pygame.draw.rect(screen, SKY_BLUE_GREY, (width - 10, 0, 10, height - 110)) # Right wall
        pygame.draw.rect(screen, SKY_BLUE_GREY, (0, height - 110, width, 10)) # Bottom wall (above conversation box)

        # Room-specific rendering
        if current_room.name == "coding_cubicle":
            for table_rect, chair_center in table_sets:
                pygame.draw.rect(screen, EARTHY_BROWN, table_rect)
                pygame.draw.circle(screen, DEEP_TEAL, chair_center, CHAIR_RADIUS)
            for x, y, name, is_key, collected in rubbish_objects:
                if not collected:
                    # All uncollected rubbish is SLIME_GREEN as per updated GDD
                    color = SLIME_GREEN 
                    
                    # Apply yellow blink if interaction is active
                    if flash_timer > 0 and object_message and name in object_message:
                        color = YELLOW
                    
                    pygame.draw.circle(screen, color, (int(x), int(y)), RUBBISH_RADIUS)

        elif current_room.name == "data_center":
            for rect in data_center_obstacles:
                pygame.draw.rect(screen, BRIGHT_ORANGE, rect)
            for x, y, name, is_key, collected in data_center_objects:
                if not collected:
                    color = YELLOW if flash_timer > 0 and object_message and name in object_message else DARK_PURPLE
                    pygame.draw.circle(screen, color, (int(x), int(y)), RUBBISH_RADIUS)

        elif current_room.name == "meeting_room":
            if meeting_room_table:
                pygame.draw.rect(screen, STEEL_BLUE_GREY, meeting_room_table)
            for chair_center in meeting_chairs:
                pygame.draw.circle(screen, DARK_PURPLE, chair_center, CHAIR_RADIUS) # Use a darker grey for chairs
            if monitor_rect:
                monitor_color = LIGHT_BLUE_SCREEN if monitor_on else DEEP_INDIGO
                pygame.draw.rect(screen, monitor_color, monitor_rect)
                # Add "monitor" text centered on the monitor
                monitor_text = small_font_obj.render("Monitor", True, WHITE)
                monitor_text_rect = monitor_text.get_rect(center=(monitor_rect.centerx, monitor_rect.centery))  # Center on monitor
                screen.blit(monitor_text, monitor_text_rect)

        elif current_room.name == "server_room":
            for rect in server_rectangles:
                pygame.draw.rect(screen, IRON_GREY, rect)
            if intern_x is not None and intern_y is not None:
                pygame.draw.circle(screen, VIBRANT_RED, (int(intern_x), int(intern_y)), INTERN_RADIUS)

        elif current_room.name == "pantry":
            for rect in pantry_rectangles:
                pygame.draw.rect(screen, CREAM_WHITE, rect) # Pantry structure color
            for x, y, collected in pantry_circles:
                if not collected:
                    color = YELLOW if flash_timer > 0 and "coffee" in object_message else ESPRESSO_BROWN
                    pygame.draw.circle(screen, color, (int(x), int(y)), RUBBISH_RADIUS)

        elif current_room.name == "secretary_room":
            if secretary_table:
                pygame.draw.rect(screen, PALE_LAVENDER, secretary_table)
            if secretary_chair_center: # Draw secretary chair
                pygame.draw.circle(screen, MUTED_CYAN, secretary_chair_center, CHAIR_RADIUS)
            pygame.draw.circle(screen, VIBRANT_RED, (int(secretary_x), int(secretary_y)), SECRETARY_RADIUS)
            # Draw secretary label
            secretary_label = small_font_obj.render("Lisa, the crumpy secretary", True, WHITE)
            secretary_label_rect = secretary_label.get_rect(center=(secretary_x - 100, secretary_y - 30))  # Position to the left of secretary
            screen.blit(secretary_label, secretary_label_rect)

        elif current_room.name == "boss_room":
            # Draw boss label
            boss_label = small_font_obj.render("Your BOSS", True, WHITE)
            boss_label_rect = boss_label.get_rect(center=(width // 2, height // 2 - 50))  # Position above boss
            screen.blit(boss_label, boss_label_rect)
            
            # Draw boss
            pygame.draw.circle(screen, BLOOD_RED, (width // 2, height // 2), BOSS_RADIUS)

        # Player (kernel shape, blinking)
        scale = 1.0 + 0.3 * (blink_timer % 20) / 20 # Increased scale range for more pronounced blink
        kernel_points = [
            (player_x - PLAYER_WIDTH // 2 * scale, player_y - PLAYER_HEIGHT // 2 * scale),
            (player_x + PLAYER_WIDTH // 2 * scale, player_y - PLAYER_HEIGHT // 2 * scale),
            (player_x, player_y + PLAYER_HEIGHT // 2 * scale)
        ]
        pygame.draw.polygon(screen, PLAYER_COLOR, [(int(p[0]), int(p[1])) for p in kernel_points])

        # Doors (using dynamically passed width and height)
        for door_type, (door_x, door_y, door_width, wall) in current_room.doors.items():
            # Adjust arc_rect calculation to use local door_x, door_y, and global width, height
            if wall == "left":
                arc_rect = (10 - DOOR_WIDTH // 2, door_y, DOOR_WIDTH, DOOR_WIDTH)
                start_angle, end_angle = (-math.pi / 2, math.pi / 2)
            elif wall == "right":
                arc_rect = (width - 10 - DOOR_WIDTH // 2, door_y, DOOR_WIDTH, DOOR_WIDTH)
                start_angle, end_angle = (math.pi / 2, math.pi * 3 / 2)
            elif wall == "top":
                # For top doors, the flat edge should be at door_y, and the arc should point downwards.
                # The start_angle and end_angle are adjusted to flip it 180 degrees horizontally.
                arc_rect = (door_x, door_y, DOOR_WIDTH, DOOR_WIDTH) 
                start_angle, end_angle = (math.pi, 2 * math.pi) # Flipped 180 degrees horizontally
            else: # bottom
                arc_rect = (door_x, height - 110 - 10 - DOOR_WIDTH // 2, DOOR_WIDTH, DOOR_WIDTH)
                start_angle, end_angle = (math.pi, 2 * math.pi)
            
            pygame.draw.arc(screen, DOOR_COLOR, arc_rect, start_angle, end_angle, DOOR_WIDTH // 2)

        # Room name (using dynamically passed width and height, moved slightly downward)
        room_name_surface = medium_font_obj.render(current_room.name.replace("_", " ").title(), True, WHITE)
        screen.blit(room_name_surface, (20, 25)) # Moved room name slightly downward

        # Draw conversation box (always show)
        pygame.draw.rect(screen, BLACK, (0, height - 100, width, 100))
        pygame.draw.rect(screen, WHITE, (0, height - 100, width, 100), 1)

        # Draw inventory prompt in top right corner of conversation box
        inventory_prompt = tiny_font_obj.render("Inventory [I]", True, WHITE)
        screen.blit(inventory_prompt, (width - 110, height - 95))  # 5px padding from top of conversation box

        # Draw inventory box when open
        if show_inventory:
            inventory_box_width = 300  # Increased from 200 to 300
            inventory_box_x = width - inventory_box_width
            inventory_box_height = (height - 100) - 10  # Extends to top of conversation box, with 10px top margin
            pygame.draw.rect(screen, BLACK, (inventory_box_x, 10, inventory_box_width, inventory_box_height))
            pygame.draw.rect(screen, WHITE, (inventory_box_x, 10, inventory_box_width, inventory_box_height), 1)

            # Draw inventory items in the box
            item_start_x = inventory_box_x + 5  # Padding from left edge of inventory box
            item_start_y = 15  # Padding from top edge of inventory box
            for i, item in enumerate(inventory):
                # Use tiny_font_obj for smaller inventory items
                item_text_surface = tiny_font_obj.render(item, True, WHITE)
                # Ensure items don't go out of bounds of inventory box
                if item_start_y + i * (tiny_font_obj.get_linesize() + 5) < inventory_box_height + 10:
                    screen.blit(item_text_surface, (item_start_x, item_start_y + i * (tiny_font_obj.get_linesize() + 5)))

        # Draw game over restart prompt
        if game_over:
            restart_text = small_font_obj.render("Press Y to restart", True, WHITE)
            restart_rect = restart_text.get_rect(center=(width//2, height - 50))
            screen.blit(restart_text, restart_rect)

        def wrap_text(text: str, font: pygame.font.Font, max_width: int) -> List[str]:
            """Wrap text to fit within max_width, breaking at punctuation when possible."""
            # First split by newlines to preserve intentional line breaks
            paragraphs = text.split('\n')
            lines = []
            
            for paragraph in paragraphs:
                # Split by sentence-ending punctuation
                sentences = []
                current = ""
                for char in paragraph:
                    current += char
                    if char in '.!?':
                        sentences.append(current.strip())
                        current = ""
                if current.strip():
                    sentences.append(current.strip())
                
                # Process each sentence
                for sentence in sentences:
                    words = sentence.split()
                    current_line = []
                    
                    for word in words:
                        test_line = ' '.join(current_line + [word])
                        if font.size(test_line)[0] <= max_width:
                            current_line.append(word)
                        else:
                            if current_line:
                                lines.append(' '.join(current_line))
                            # If a single word is too long, break it at hyphens or underscores
                            if '-' in word or '_' in word:
                                parts = word.replace('-', ' - ').replace('_', ' _ ').split()
                                for part in parts:
                                    if font.size(part)[0] <= max_width:
                                        current_line = [part]
                                    else:
                                        # If still too long, break into characters
                                        chars = list(part)
                                        current_line = []
                                        for char in chars:
                                            test_line = ' '.join(current_line + [char])
                                            if font.size(test_line)[0] <= max_width:
                                                current_line.append(char)
                                            else:
                                                if current_line:
                                                    lines.append(''.join(current_line))
                                                current_line = [char]
                            else:
                                current_line = [word]
                    
                    if current_line:
                        lines.append(' '.join(current_line))
            
            return lines

        def render_wrapped_text(text: str, y_pos: int, font: pygame.font.Font = small_font_obj) -> None:
            """Render wrapped text centered in the conversation box."""
            if not text:
                return
            
            lines = wrap_text(text, font, width - 40)  # 20px padding on each side
            line_height = font.get_linesize()
            total_height = len(lines) * line_height
            
            # Start from the top of the conversation box
            start_y = height - 100 + (100 - total_height) // 2
            
            for i, line in enumerate(lines):
                text_surface = font.render(line, True, WHITE)
                text_rect = text_surface.get_rect(center=(width//2, start_y + i * line_height))
                screen.blit(text_surface, text_rect)

        # Message display order (priority based)
        if show_end_screen:
            render_wrapped_text(victory_message, height - 50)
        elif trap_message:
            render_wrapped_text(trap_message, height - 50)
        elif room_instruction_timer > 0:
            render_wrapped_text(room_instruction, height - 50)
        elif password_mode and current_room.name != "boss_room":
            render_wrapped_text(password_message, height - 50)
        elif key_message_timer > 0:
            render_wrapped_text(key_message, height - 50)
        elif table_message_timer > 0:
            render_wrapped_text(table_message, height - 50)
        elif monitor_timer > 0:
            render_wrapped_text(monitor_message, height - 50)
        elif intern_message:
            render_wrapped_text(intern_message, height - 50)
        elif object_message_timer > 0:
            render_wrapped_text(object_message, height - 50)
        elif door_message:
            render_wrapped_text(door_message, height - 50)
        elif current_room.name == "boss_room":
            render_wrapped_text("I'm so nervous...", height - 50)

        # Draw password input if active
        if password_mode and password_message:
            # Use the appropriate font for the message
            font_to_use = TINY_FONT if current_room.name == "boss_room" else SMALL_FONT
            wrapped_message = wrap_text(password_message, font_to_use, width - 40)
            
            if current_room.name == "boss_room":
                # For boss room, display message to the left of the boss
                for i, line in enumerate(wrapped_message):
                    text_surface = font_to_use.render(line, True, WHITE)
                    text_rect = text_surface.get_rect(midright=(width // 2 - 50, height // 3 + i * (font_to_use.get_linesize() + 5)))
                    screen.blit(text_surface, text_rect)
                
                # Draw password input below the message
                input_text = password_input + ("|" if int(pygame.time.get_ticks() / 500) % 2 == 0 else "")
                input_surface = font_to_use.render(input_text, True, WHITE)
                input_rect = input_surface.get_rect(midright=(width // 2 - 50, height // 3 + len(wrapped_message) * (font_to_use.get_linesize() + 5)))
                screen.blit(input_surface, input_rect)
            else:
                # For other rooms, display message in center
                for i, line in enumerate(wrapped_message):
                    text_surface = font_to_use.render(line, True, WHITE)
                    text_rect = text_surface.get_rect(center=(width // 2, height // 2 - 50 + i * (font_to_use.get_linesize() + 5)))
                    screen.blit(text_surface, text_rect)
                
                # Draw password input
                input_text = password_input + ("|" if int(pygame.time.get_ticks() / 500) % 2 == 0 else "")
                input_surface = font_to_use.render(input_text, True, WHITE)
                input_rect = input_surface.get_rect(center=(width // 2, height // 2 + 50))
                screen.blit(input_surface, input_rect)

    except pygame.error as e: # Catch specific Pygame errors
        print(f"Pygame error in render_game: {e}")
        # Optionally, display a simple error message on screen
        error_text = medium_font_obj.render("RENDER ERROR!", True, BLOOD_RED)
        error_rect = error_text.get_rect(center=(width // 2, height // 2))
        screen.blit(error_text, error_rect)
    except Exception as e: # Catch other general exceptions
        print(f"General error in render_game: {e}")
        error_text = medium_font_obj.render("RENDER ERROR!", True, BLOOD_RED)
        error_rect = error_text.get_rect(center=(width // 2, height // 2))
        screen.blit(error_text, error_rect)
