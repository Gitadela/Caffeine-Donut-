from dataclasses import dataclass
from typing import Dict, Tuple
# Import specific constants needed, excluding WIDTH and HEIGHT
from constants import (
    DOOR_WIDTH, SHARP_PINK, DARK_YELLOW, SHARP_GREEN, COOL_GREY,
    CHARCOAL_GREY, ORANGE, LIGHT_BLUE, BLACK
)

@dataclass
class Room:
    """Room configuration (GDD Sections 4–5)."""
    name: str
    entry: Tuple[int, int]
    next_room: str # This will be None for the final room or if no direct next room
    doors: Dict[str, Tuple[int, int, int, str]] # Changed to Tuple[x,y,width,wall_side]
    background_color: Tuple[int, int, int]
    # width and height will now be passed dynamically to setup_rooms
    width: int
    height: int

def setup_rooms(width: int, height: int) -> Dict[str, Room]:
    """Configure rooms with doors (GDD Section 5), using dynamic width and height."""
    rooms = {
        "lobby": Room( # Renamed from "office_entry" to "lobby" for GDD consistency
            name="lobby",
            # User's Initial Location: In front of the right door.
            entry=(width - 50, height // 2), 
            next_room="coding_cubicle",
            doors={
                "next": (0, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "left"), # Left door
                "trap_right": (width - DOOR_WIDTH, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "right"), # Right trap
                # For top door, its y-coordinate should be 10 for its linear side to align with the top wall.
                # The rendering will handle the flip (curved part pointing downwards).
                "trap_top": (width // 2 - DOOR_WIDTH // 2, 10, DOOR_WIDTH, "top"), 
            },
            background_color=SHARP_PINK, # Updated color constant
            width=width,
            height=height
        ),
        "coding_cubicle": Room(
            name="coding_cubicle",
            # User's Initial Location: In front of the right door.
            entry=(width - 50, height // 2), 
            next_room="data_center",
            doors={
                "next": (0, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "left"), # Left door
                "right_inaccessible": (width - DOOR_WIDTH, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "right"), # Inaccessible right door
            },
            background_color=DARK_YELLOW, # Updated color constant
            width=width,
            height=height
        ),
        "data_center": Room(
            name="data_center",
            # User's Initial Location: In front of the right door.
            # Player is currently stuck at initial position at Room 3.
            # Changed entry to be towards the right side to prevent being stuck near obstacles.
            entry=(width - 100, height // 2), 
            next_room="meeting_room",
            doors={
                "next": (0, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "left"),
                "right_inaccessible": (width - DOOR_WIDTH, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "right"), # Inaccessible right door
            },
            background_color=SHARP_GREEN, # Updated color constant
            width=width,
            height=height
        ),
        "meeting_room": Room(
            name="meeting_room",
            # User's Initial Location: In front of the right door.
            entry=(width - 50, height // 2), 
            next_room="server_room",
            doors={
                "next": (0, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "left"),
                "right_inaccessible": (width - DOOR_WIDTH, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "right"), # Inaccessible right door
            },
            background_color=COOL_GREY, # Updated color constant
            width=width,
            height=height
        ),
        "server_room": Room(
            name="server_room",
            # User's Initial Location: In front of the right door.
            entry=(width - 50, height // 2), 
            next_room="pantry",
            doors={
                "next": (0, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "left"),
                "right_inaccessible": (width - DOOR_WIDTH, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "right"), # Inaccessible right door
            },
            background_color=CHARCOAL_GREY, # Updated color constant
            width=width,
            height=height
        ),
        "pantry": Room(
            name="pantry",
            # User's Initial Location: In front of the right door.
            entry=(width - 50, height // 2), 
            next_room="secretary_room",
            doors={
                "next": (0, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "left"),
                "right_inaccessible": (width - DOOR_WIDTH, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "right"), # Inaccessible right door
            },
            background_color=ORANGE,
            width=width,
            height=height
        ),
        "secretary_room": Room(
            name="secretary_room",
            # User's Initial Location: In front of the right door.
            entry=(width - 50, height // 2), 
            next_room="boss_room",
            doors={
                "next": (0, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "left"),
                "right_inaccessible": (width - DOOR_WIDTH, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "right"), # Inaccessible right door
                "trap_top1": (width // 4 - DOOR_WIDTH // 2, 0, DOOR_WIDTH, "top"), # Evenly spaced traps
                "trap_top2": (3 * width // 4 - DOOR_WIDTH // 2, 0, DOOR_WIDTH, "top"), # Evenly spaced traps
                "trap_bottom": (width // 2 - DOOR_WIDTH // 2, height - 110 - DOOR_WIDTH, DOOR_WIDTH, "bottom"),
            },
            background_color=LIGHT_BLUE,
            width=width,
            height=height
        ),
        "boss_room": Room(
            name="boss_room",
            # User's Initial Location: In front of the right door.
            entry=(width - 50, height // 2), 
            next_room=None, # Final room, no next_room
            doors={
                "entry": (0, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "left"), # Entry from secretary room
                "right_inaccessible": (width - DOOR_WIDTH, height // 2 - DOOR_WIDTH // 2, DOOR_WIDTH, "right"), # Inaccessible right door
            },
            background_color=BLACK,
            width=width,
            height=height
        ),
    }
    return rooms

