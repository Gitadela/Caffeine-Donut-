import asyncio
import pygame
import sys
import platform
import math

# Import necessary constants directly, excluding WIDTH and HEIGHT
from constants import (
    PLAYER_SPEED, PLAYER_WIDTH, PLAYER_HEIGHT, PLAYER_COLOR,
    DOOR_WIDTH, DOOR_COLOR, RUBBISH_RADIUS, INTERN_SPEED, INTERN_RADIUS,
    SECRETARY_RADIUS, BOSS_RADIUS, TABLE_WIDTH, TABLE_HEIGHT, CHAIR_RADIUS,
    DATA_CENTER_RECT_WIDTH, DATA_CENTER_RECT_HEIGHT, MEETING_TABLE_WIDTH, MEETING_TABLE_HEIGHT,
    GAME_STATE_START, GAME_STATE_PLAY, MESSAGE_DURATION, PASSWORD_DURATION,
    COOLDOWN_DURATION, ROOM3_PASSWORD, ROOM4_PASSWORD, ROOM8_PASSWORD, COFFEE_REQUIRED,
    ROOM_INSTRUCTIONS, FPS, WHITE, GREY, YELLOW, EARTHY_BROWN, DEEP_TEAL, CREAM_WHITE,
    SLIME_GREEN, GOLD_YELLOW, BRIGHT_ORANGE, DARK_PURPLE, STEEL_BLUE_GREY, DEEP_INDIGO,
    LIGHT_BLUE_SCREEN, IRON_GREY, ESPRESSO_BROWN, PALE_LAVENDER, MUTED_CYAN, VIBRANT_RED,
    BLOOD_RED, SHARP_PINK, DARK_YELLOW, SHARP_GREEN, COOL_GREY, CHARCOAL_GREY, ORANGE, LIGHT_BLUE, BLACK,
    LARGE_FONT_SIZE, MEDIUM_FONT_SIZE, SMALL_FONT_SIZE, TINY_FONT_SIZE # Standardized font size names
)
from room import setup_rooms, Room
from render import render_game
from start import show_start_screen # Ensure this is the only import for show_start_screen
from game_objects import (
    setup_rubbish_and_tables,
    setup_data_center_objects,
    setup_meeting_room_objects,
    setup_server_room_objects,
    setup_pantry_room,
    setup_secretary_room_objects,
)
from utils import play_sound, play_background_music, stop_background_music

# Global screen dimensions (can be changed by VIDEORESIZE event)
WIDTH = 800
HEIGHT = 600

# Initialize Pygame
pygame.init()
pygame.mixer.init()
pygame.font.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("Caffeine Donut (́◉◞౪◟◉‵)")
clock = pygame.time.Clock()

# Initialize fonts (GDD Section 2)
# Updated font filename from "press_start_2p.ttf" to "pressstart2p.ttf"
FONT_PATH = "assets/pressstart2p.ttf"
try:
    # Using standardized font size constants and names
    LARGE_FONT = pygame.font.Font(FONT_PATH, LARGE_FONT_SIZE)
    MEDIUM_FONT = pygame.font.Font(FONT_PATH, MEDIUM_FONT_SIZE)
    SMALL_FONT = pygame.font.Font(FONT_PATH, SMALL_FONT_SIZE)
    TINY_FONT = pygame.font.Font(FONT_PATH, TINY_FONT_SIZE) # Standardized name
except FileNotFoundError:
    print("Custom font 'pressstart2p.ttf' not found. Using Courier New as fallback.")
    # Using standardized font size constants and names for fallback
    LARGE_FONT = pygame.font.SysFont("couriernew", LARGE_FONT_SIZE)
    MEDIUM_FONT = pygame.font.SysFont("couriernew", MEDIUM_FONT_SIZE)
    SMALL_FONT = pygame.font.SysFont("couriernew", SMALL_FONT_SIZE)
    TINY_FONT = pygame.font.SysFont("couriernew", TINY_FONT_SIZE) # Standardized name

# Global variables (all explicitly declared for clarity and modification)
game_state = GAME_STATE_START
rooms = setup_rooms(WIDTH, HEIGHT) # Pass initial WIDTH, HEIGHT
current_room = rooms["lobby"]
# Updated initial player position for lobby to be in front of the right door
player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
inventory = []
has_key = False
password_mode = False
password_input = ""
password_message = ""
password_message_timer = 0
password_cooldown = 0
key_message = ""
key_message_timer = 0
table_message = ""
table_message_timer = 0
monitor_message = ""
monitor_timer = 0
monitor_on = False
intern_message = ""
object_message = ""
object_message_timer = 0
game_over = False
escaped = False
trap_message = ""
victory_message = ""
restart_confirm_window = False
room_instruction = ROOM_INSTRUCTIONS[current_room.name]
room_instruction_timer = MESSAGE_DURATION
freeze_movement = True
freeze_timer = MESSAGE_DURATION
blink_timer = 0
flash_timer = 0
door_message = ""
door_confirmation = False # This flag is now about expecting keyboard Y/N input
nearest_door = None
door_prompt_timer = 0 # New timer for door prompt duration
show_end_screen = False
music_playing = False
show_inventory = False
inventory_prompt = "Inventory = [I]"

# Setup game objects for each room, passing initial WIDTH, HEIGHT
rubbish_objects, table_sets = setup_rubbish_and_tables(WIDTH, HEIGHT)
data_center_objects, data_center_obstacles = setup_data_center_objects(WIDTH, HEIGHT)
meeting_table, meeting_chairs, monitor_rect = setup_meeting_room_objects(WIDTH, HEIGHT)
# Correctly capture intern_path from setup_server_room_objects
server_rectangles, intern_x, intern_y, intern_path = setup_server_room_objects(WIDTH, HEIGHT)
pantry_rectangles, pantry_circles = setup_pantry_room(WIDTH, HEIGHT)
secretary_table, secretary_chair_center, secretary_x, secretary_y = setup_secretary_room_objects(WIDTH, HEIGHT)

intern_path_index = 0

# Start background music if not already playing
if not music_playing:
    try:
        play_background_music()
        music_playing = True
    except pygame.error as e:
        print(f"Error playing background music: {e}")
        pass

def check_door_collision(player_rect: pygame.Rect, current_room_obj: 'Room', width: int, height: int) -> tuple:
    """Check if player collides with any half-circle door (GDD Section 4).
       Returns (door_type, is_trap, is_inaccessible)"""
    try:
        for door_type, (door_x, door_y, width_door_def, wall) in current_room_obj.doors.items():
            door_x_val = float(door_x or 0)
            door_y_val = float(door_y or 0)
            door_radius = width_door_def / 2

            # Calculate circle center for collision check based on wall
            # All doors are half-circles seamlessly integrated with the wall
            if wall == "left":
                door_center_x = 10 + door_radius  # Left wall, vertically centered
                door_center_y = door_y_val + door_radius
            elif wall == "right":
                door_center_x = width - 10 - door_radius  # Right wall, vertically centered
                door_center_y = door_y_val + door_radius
            elif wall == "top":
                door_center_x = door_x_val + door_radius  # Top wall, horizontally centered
                door_center_y = 10 + door_radius  # Flipped 180 degrees horizontally (curved part downwards)
            else:  # bottom
                door_center_x = door_x_val + door_radius  # Bottom wall, horizontally centered
                door_center_y = (height - 110 - 10) - door_radius

            player_center_x = player_rect.centerx
            player_center_y = player_rect.centery

            # Check collision using distance from player center to door center
            distance = ((player_center_x - door_center_x) ** 2 + (player_center_y - door_center_y) ** 2) ** 0.5
            if distance < door_radius + PLAYER_WIDTH / 2:
                is_trap = door_type.startswith("trap")
                is_inaccessible = door_type.endswith("inaccessible")
                return door_type, is_trap, is_inaccessible
        return None, False, False
    except Exception as e:
        print(f"Error in check_door_collision: {e}")
        return None, False, False

def reset_game():
    """Reset game state to initial values (GDD Section 1)."""
    global game_state, current_room, player_x, player_y, inventory, has_key, password_mode
    global password_input, password_message, password_message_timer, password_cooldown
    global key_message, key_message_timer, table_message, table_message_timer
    global monitor_message, monitor_timer, monitor_on, intern_message, object_message
    global object_message_timer, game_over, escaped, trap_message, victory_message
    global restart_confirm_window, room_instruction, room_instruction_timer, freeze_movement
    global freeze_timer, blink_timer, flash_timer, door_message, door_confirmation
    global nearest_door, door_prompt_timer, show_end_screen, show_inventory, rubbish_objects, table_sets
    global data_center_objects, data_center_obstacles, meeting_table, meeting_chairs
    global monitor_rect, server_rectangles, intern_x, intern_y, pantry_rectangles
    global pantry_circles, secretary_table, secretary_chair_center, secretary_x, secretary_y, intern_path_index
    global music_playing, WIDTH, HEIGHT, rooms, intern_path # Include intern_path here as it's reset
    # Also reinitialize fonts here to prevent potential issues on restart
    global LARGE_FONT, MEDIUM_FONT, SMALL_FONT, TINY_FONT

    game_state = GAME_STATE_START
    rooms = setup_rooms(WIDTH, HEIGHT) # Re-setup rooms for current dimensions
    current_room = rooms["lobby"]
    # Updated initial player position for lobby to be in front of the right door on reset
    player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
    inventory.clear()
    has_key = False
    password_mode = False
    password_input = ""
    password_message = ""
    password_message_timer = 0
    password_cooldown = 0
    key_message = ""
    key_message_timer = 0
    table_message = ""
    table_message_timer = 0
    monitor_message = ""
    monitor_timer = 0
    monitor_on = False
    intern_message = ""
    object_message = ""
    object_message_timer = 0
    game_over = False
    escaped = False
    trap_message = ""
    victory_message = ""
    restart_confirm_window = False
    room_instruction = ROOM_INSTRUCTIONS[current_room.name]
    room_instruction_timer = MESSAGE_DURATION
    freeze_movement = True
    freeze_timer = MESSAGE_DURATION
    blink_timer = 0
    flash_timer = 0
    door_message = ""
    door_confirmation = False
    nearest_door = None
    door_prompt_timer = 0 # Reset door prompt timer
    show_end_screen = False
    show_inventory = False
    inventory_prompt = "Inventory = [I]"
    music_playing = False # Reset to ensure music restarts

    # Re-setup all game objects to their initial states (important for responsiveness)
    # Pass current WIDTH, HEIGHT to setup functions
    rubbish_objects, table_sets = setup_rubbish_and_tables(WIDTH, HEIGHT)
    data_center_objects, data_center_obstacles = setup_data_center_objects(WIDTH, HEIGHT)
    meeting_table, meeting_chairs, monitor_rect = setup_meeting_room_objects(WIDTH, HEIGHT)
    # Correctly capture intern_path from setup_server_room_objects
    server_rectangles, intern_x, intern_y, intern_path = setup_server_room_objects(WIDTH, HEIGHT)
    pantry_rectangles, pantry_circles = setup_pantry_room(WIDTH, HEIGHT)
    secretary_table, secretary_chair_center, secretary_x, secretary_y = setup_secretary_room_objects(WIDTH, HEIGHT)
    intern_path_index = 0

    # Reinitialize fonts
    try:
        LARGE_FONT = pygame.font.Font(FONT_PATH, LARGE_FONT_SIZE)
        MEDIUM_FONT = pygame.font.Font(FONT_PATH, MEDIUM_FONT_SIZE)
        SMALL_FONT = pygame.font.Font(FONT_PATH, SMALL_FONT_SIZE)
        TINY_FONT = pygame.font.Font(FONT_PATH, TINY_FONT_SIZE)
    except FileNotFoundError:
        print("Font loading failed on reset, using fallback.")
        LARGE_FONT = pygame.font.SysFont("couriernew", LARGE_FONT_SIZE)
        MEDIUM_FONT = pygame.font.SysFont("couriernew", MEDIUM_FONT_SIZE)
        SMALL_FONT = pygame.font.SysFont("couriernew", SMALL_FONT_SIZE)
        TINY_FONT = pygame.font.SysFont("couriernew", TINY_FONT_SIZE)

    # Restart background music
    try:
        play_background_music()
        music_playing = True
    except pygame.error as e:
        print(f"Error playing background music on reset: {e}")

def handle_door_confirmation(action_key: str):
    """Helper function to handle door confirmation logic, reusable for keyboard and touch."""
    global game_state, current_room, player_x, player_y, inventory, has_key, password_mode
    global password_input, password_message, password_message_timer, password_cooldown
    global key_message, key_message_timer, table_message, table_message_timer
    global monitor_message, monitor_timer, monitor_on, intern_message, object_message
    global object_message_timer, game_over, escaped, trap_message, victory_message
    global restart_confirm_window, room_instruction, room_instruction_timer, freeze_movement
    global freeze_timer, blink_timer, flash_timer, door_message, door_confirmation
    global nearest_door, door_prompt_timer, show_end_screen, rooms, WIDTH, HEIGHT # Add door_prompt_timer

    door_type, is_trap, is_inaccessible = nearest_door

    # Reset all message timers to clear the current message before proceeding
    password_mode = False
    password_message_timer = 0
    key_message_timer = 0
    table_message_timer = 0
    monitor_timer = 0
    object_message_timer = 0
    door_confirmation = False # Reset confirmation flag
    nearest_door = None
    door_message = ""
    room_instruction_timer = 0
    freeze_timer = 0
    door_prompt_timer = 0 # Reset door prompt timer
    freeze_movement = False # Unfreeze movement after door decision

    if action_key == 'y':
        if is_trap:
            try:
                play_sound("trap")
            except pygame.error:
                pass
            trap_messages = {
                "lobby_trap_top": "Zoom trap—muted in eternal silence!\n"
                                "Game Over. Press [Y] to restart.",
                "lobby_trap_right": "Coffee spill—drowned in decaf despair!\n"
                                  "Game Over. Press [Y] to restart.",
                "secretary_room_trap_top1": "Paperwork avalanche—buried in bureaucracy!\n"
                                          "Game Over. Press [Y] to restart.",
                "secretary_room_trap_top2": "Fax explosion—incinerated by obsolete tech!\n"
                                          "Game Over. Press [Y] to restart.",
                "secretary_room_trap_bottom": "Stapler ambush—punctured and pointless!\n"
                                            "Game Over. Press [Y] to restart."
            }
            trap_key = f"{current_room.name}_{door_type}"
            trap_message = trap_messages[trap_key]
            game_over = True
            restart_confirm_window = True
        elif is_inaccessible:
            key_message = "This door is locked. Corporate policy: no unauthorized exits."
            key_message_timer = MESSAGE_DURATION
        elif door_type == "next":
            if current_room.name == "coding_cubicle":
                if not has_key:
                    key_message = "I need a key to unlock it... or perhaps a promotion. Both are equally unlikely."
                    key_message_timer = MESSAGE_DURATION
                else:
                    try:
                        play_sound("door")
                    except pygame.error:
                        pass
                    if current_room.next_room:
                        current_room = rooms[current_room.next_room]
                        player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
                        room_instruction = ROOM_INSTRUCTIONS[current_room.name]
                        room_instruction_timer = MESSAGE_DURATION
                        freeze_movement = True
                        freeze_timer = MESSAGE_DURATION
            elif current_room.name == "data_center":
                password_mode = True
                password_message = (
                    "Enter password. Hint: Run `print(chr(99) + chr(105) + chr(112))`. Don't screw it up."
                )
                password_message_timer = PASSWORD_DURATION
            elif current_room.name == "meeting_room":
                password_mode = True
                password_message = "Enter password. Think hard, genius."
                password_message_timer = PASSWORD_DURATION
            elif current_room.name == "pantry":
                coffee_count = 0
                for item in inventory:
                    if "instant coffee stick" in item:
                        try:
                            quantity_str = item.split("x")[-1].strip()
                            quantity = int(quantity_str)
                            coffee_count += quantity
                        except (ValueError, IndexError):
                            coffee_count += 1
                
                if coffee_count >= COFFEE_REQUIRED:
                    try:
                        play_sound("door")
                    except pygame.error:
                        pass
                    if current_room.next_room:
                        current_room = rooms[current_room.next_room]
                        player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
                        room_instruction = ROOM_INSTRUCTIONS[current_room.name]
                        room_instruction_timer = MESSAGE_DURATION
                        freeze_movement = True
                        freeze_timer = MESSAGE_DURATION
                else:
                    key_message = (
                        f"Need {COFFEE_REQUIRED - coffee_count} more instant coffee sticks. ({coffee_count}/{COFFEE_REQUIRED})"
                    )
                    key_message_timer = MESSAGE_DURATION
            else:
                try:
                    play_sound("door")
                except pygame.error:
                    pass
                if current_room.next_room:
                    current_room = rooms[current_room.next_room]
                    player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
                    room_instruction = ROOM_INSTRUCTIONS[current_room.name]
                    room_instruction_timer = MESSAGE_DURATION
                    freeze_movement = True
                    freeze_timer = MESSAGE_DURATION
        elif door_type == "entry":
            key_message = "You can't go back home, it's office hours. Get back to work!"
            key_message_timer = MESSAGE_DURATION
    elif action_key == 'n': # Decline door interaction - Implement bounce back horizontally
        # Determine the door's wall side to apply the correct bounce direction
        door_info_tuple = rooms[current_room.name].doors[door_type]
        door_wall_side = door_info_tuple[3] # 'left', 'right', 'top', 'bottom'
        
        bounce_distance = PLAYER_WIDTH * 2 # How far to bounce back

        # GDD states "bounce back horizontally", so adjust player_x.
        # This will move the player left/right away from the door regardless of wall.
        if door_wall_side == "left": # Door on left, bounce right
            player_x += bounce_distance
        elif door_wall_side == "right": # Door on right, bounce left
            player_x -= bounce_distance
        elif door_wall_side == "top": # Door on top, decide based on player's current x-position relative to door
            door_center_x = door_info_tuple[0] + DOOR_WIDTH // 2
            if player_x <= door_center_x: # If player is left of or at door center, bounce left
                player_x -= bounce_distance
            else: # If player is right of door center, bounce right
                player_x += bounce_distance
        elif door_wall_side == "bottom": # Door on bottom, decide based on player's current x-position relative to door
            door_center_x = door_info_tuple[0] + DOOR_WIDTH // 2
            if player_x <= door_center_x: # If player is left of or at door center, bounce left
                player_x -= bounce_distance
            else: # If player is right of door center, bounce right
                player_x += bounce_distance

        # Ensure player doesn't go through walls due to bounce
        player_x = max(10 + PLAYER_WIDTH // 2, min(WIDTH - 10 - PLAYER_WIDTH // 2, player_x))
        player_y = max(10 + PLAYER_HEIGHT // 2, min(HEIGHT - 110 - 10 - PLAYER_HEIGHT // 2, player_y))


def handle_events():
    """Handle user input events (GDD Section 1)."""
    global game_state, screen, WIDTH, HEIGHT, inventory, has_key, password_mode, password_input
    global password_message, password_message_timer, password_cooldown, key_message, key_message_timer
    global table_message, table_message_timer, monitor_message, monitor_timer, monitor_on
    global intern_message, object_message, object_message_timer, door_message, door_confirmation, nearest_door
    global game_over, escaped, trap_message, victory_message, restart_confirm_window, show_end_screen
    global room_instruction, room_instruction_timer, freeze_movement, freeze_timer, show_inventory
    global rubbish_objects, table_sets, data_center_objects, data_center_obstacles
    global meeting_table, meeting_chairs, monitor_rect, server_rectangles, intern_x, intern_y
    global pantry_circles, pantry_rectangles, secretary_table, secretary_chair_center, secretary_x, secretary_y
    global player_x, player_y, blink_timer, flash_timer, rooms, intern_path, door_prompt_timer # Add door_prompt_timer

    player_rect = pygame.Rect(
        int(player_x - PLAYER_WIDTH // 2),
        int(player_y - PLAYER_HEIGHT // 2),
        PLAYER_WIDTH,
        PLAYER_HEIGHT,
    )

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            stop_background_music()
            pygame.quit()
            sys.exit()
        elif event.type == pygame.VIDEORESIZE:
            old_width, old_height = WIDTH, HEIGHT # Store old dimensions
            WIDTH, HEIGHT = event.w, event.h # Update global WIDTH and HEIGHT
            screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
            
            # Scale player position proportionally
            scale_x = WIDTH / old_width
            scale_y = HEIGHT / old_height
            player_x *= scale_x
            player_y *= scale_y

            # Re-clamp player position to ensure it's within new wall boundaries
            player_x = max(10 + PLAYER_WIDTH // 2, min(WIDTH - 10 - PLAYER_WIDTH // 2, player_x))
            player_y = max(10 + PLAYER_HEIGHT // 2, min(HEIGHT - 110 - 10 - PLAYER_HEIGHT // 2, player_y))

            # Re-setup all game objects to adapt to new dimensions
            global current_room 
            rooms = setup_rooms(WIDTH, HEIGHT) # Recreate rooms with new dimensions
            current_room = rooms[current_room.name] # Keep player in current room after resize

            rubbish_objects, table_sets = setup_rubbish_and_tables(WIDTH, HEIGHT)
            data_center_objects, data_center_obstacles = setup_data_center_objects(WIDTH, HEIGHT)
            meeting_table, meeting_chairs, monitor_rect = setup_meeting_room_objects(WIDTH, HEIGHT)
            server_rectangles, intern_x, intern_y, intern_path = setup_server_room_objects(WIDTH, HEIGHT) # Update intern_path
            pantry_rectangles, pantry_circles = setup_pantry_room(WIDTH, HEIGHT)
            secretary_table, secretary_chair_center, secretary_x, secretary_y = setup_secretary_room_objects(WIDTH, HEIGHT)

        elif event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.FINGERDOWN:
            mouse_x, mouse_y = event.pos if event.type == pygame.MOUSEBUTTONDOWN else (event.x * WIDTH, event.y * HEIGHT)

            # Check for inventory toggle click (remains as a click interaction for UI visibility)
            inventory_prompt_area_rect = pygame.Rect(WIDTH - 200, HEIGHT - 110, 200, 110) # Approx area for prompt
            if inventory_prompt_area_rect.collidepoint(mouse_x, mouse_y):
                show_inventory = not show_inventory
                # Clear all other messages when inventory is toggled
                password_mode = False
                password_message = ""
                password_message_timer = 0
                key_message = ""
                key_message_timer = 0
                table_message = ""
                table_message_timer = 0
                monitor_message = ""
                monitor_timer = 0
                object_message = ""
                object_message_timer = 0
                door_confirmation = False
                nearest_door = None
                door_message = ""
                room_instruction_timer = 0
                freeze_timer = 0
                door_prompt_timer = 0 # Also clear this if inventory is toggled
                continue # Skip other checks for this event

            # The mouse-based door confirmation logic is removed as per GDD.

            # Only allow monitor click if player is actually at the monitor (object interaction)
            # The monitor interaction should trigger a Y/N prompt, then wait for Y/N key press.
            # So, a direct click to turn on/off is replaced by a Y/N prompt, similar to doors.
            if current_room.name == "meeting_room" and monitor_rect and player_rect.colliderect(monitor_rect) and monitor_timer <= 0 and not monitor_message and not door_confirmation and not password_mode:
                monitor_message = "Turn on the monitor? [Y] = Yes, [N] = No"
                monitor_timer = MESSAGE_DURATION # Set a timer for the prompt
                # No monitor_on = True here, it's set on Y press.
                # Clear other active messages
                password_mode = False
                password_message_timer = 0
                key_message_timer = 0
                table_message_timer = 0
                object_message_timer = 0
                door_confirmation = False # Clear door prompt state if active
                nearest_door = None
                door_message = ""
                room_instruction_timer = 0
                freeze_timer = 0
                door_prompt_timer = 0 # Ensure door prompt is cleared
                try:
                    play_sound("treasure")
                except pygame.error:
                    pass

        elif event.type == pygame.KEYDOWN:
            if game_state == GAME_STATE_START: # Only accept spacebar on start screen
                if event.key == pygame.K_SPACE:
                    game_state = GAME_STATE_PLAY
                    # Re-initialize all necessary game state variables upon starting a new game
                    # Pass WIDTH, HEIGHT to setup_rooms
                    rooms = setup_rooms(WIDTH, HEIGHT)
                    current_room = rooms["lobby"]
                    # Updated initial player position for lobby to be in front of the right door
                    player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
                    inventory.clear()
                    has_key = False
                    password_mode = False
                    password_input = ""
                    password_message = ""
                    password_message_timer = 0
                    password_cooldown = 0
                    key_message = ""
                    key_message_timer = 0
                    table_message = ""
                    table_message_timer = 0
                    monitor_message = ""
                    monitor_timer = 0
                    monitor_on = False
                    intern_message = ""
                    object_message = ""
                    object_message_timer = 0
                    game_over = False
                    escaped = False
                    trap_message = ""
                    victory_message = ""
                    restart_confirm_window = False
                    room_instruction = ROOM_INSTRUCTIONS[current_room.name]
                    room_instruction_timer = MESSAGE_DURATION
                    freeze_movement = True
                    freeze_timer = MESSAGE_DURATION
                    blink_timer = 0
                    flash_timer = 0
                    door_message = ""
                    door_confirmation = False
                    nearest_door = None
                    door_prompt_timer = 0 # Reset door prompt timer on start
                    show_end_screen = False
                    music_playing = False # Ensure music is marked as not playing to allow restart
                    show_inventory = False
                    inventory_prompt = "Inventory = [I]"

                    # Re-setup all game objects, passing current WIDTH, HEIGHT
                    rubbish_objects, table_sets = setup_rubbish_and_tables(WIDTH, HEIGHT)
                    data_center_objects, data_center_obstacles = setup_data_center_objects(WIDTH, HEIGHT)
                    meeting_table, meeting_chairs, monitor_rect = setup_meeting_room_objects(WIDTH, HEIGHT)
                    # Correctly capture intern_path from setup_server_room_objects
                    server_rectangles, intern_x, intern_y, intern_path = setup_server_room_objects(WIDTH, HEIGHT)
                    pantry_rectangles, pantry_circles = setup_pantry_room(WIDTH, HEIGHT)
                    secretary_table, secretary_chair_center, secretary_x, secretary_y = setup_secretary_room_objects(WIDTH, HEIGHT)
                    intern_path_index = 0

                    if not music_playing:
                        try:
                            play_background_music()
                            music_playing = True
                        except pygame.error as e:
                            print(f"Error playing background music: {e}")
                            pass
            elif show_end_screen or game_over: # Handling restart/quit after game end
                if event.key == pygame.K_y:
                    reset_game()
                elif event.key == pygame.K_n:
                    stop_background_music()
                    pygame.quit()
                    sys.exit()
            else: # Game is in play state
                if password_cooldown <= 0 and password_mode: # If currently in password input mode
                    if event.key == pygame.K_RETURN:
                        if current_room.name == "data_center":
                            if password_input.lower() == ROOM3_PASSWORD:
                                password_mode = False
                                password_input = ""
                                password_message = "Door unlocked. Don't get cocky."
                                password_message_timer = MESSAGE_DURATION
                                password_cooldown = 0 # Reset cooldown after correct password
                                # Clear all other message timers to ensure only new message shows
                                key_message_timer = 0
                                table_message_timer = 0
                                monitor_timer = 0
                                object_message_timer = 0
                                door_confirmation = False
                                nearest_door = None
                                door_message = ""
                                room_instruction_timer = 0
                                freeze_timer = 0
                                door_prompt_timer = 0
                                try:
                                    play_sound("door")
                                except pygame.error:
                                    pass
                                if current_room.next_room:
                                    current_room = rooms[current_room.next_room]
                                    # Position player on the right-hand side when entering new room
                                    player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
                                    room_instruction = ROOM_INSTRUCTIONS[current_room.name]
                                    room_instruction_timer = MESSAGE_DURATION
                                    freeze_movement = True
                                    freeze_timer = MESSAGE_DURATION
                            else:
                                password_message = (
                                    f"Access Denied. Your professional development plan is now overdue.\n"
                                    f"Hint: Run `print(chr(99) + chr(105) + chr(112))`."
                                )
                                password_message_timer = MESSAGE_DURATION
                                password_cooldown = COOLDOWN_DURATION
                                password_input = ""
                                key_message_timer = 0
                                table_message_timer = 0
                                monitor_timer = 0
                                object_message_timer = 0
                                door_confirmation = False
                                nearest_door = None
                                door_message = ""
                                room_instruction_timer = 0
                                freeze_timer = 0
                                door_prompt_timer = 0
                        elif current_room.name == "meeting_room":
                            if password_input.lower() == ROOM4_PASSWORD:
                                password_mode = False
                                password_input = ""
                                password_message = "Unlocked. You're not *completely* incompetent."
                                password_message_timer = MESSAGE_DURATION
                                password_cooldown = 0 # Reset cooldown after correct password
                                key_message_timer = 0
                                table_message_timer = 0
                                monitor_timer = 0
                                object_message_timer = 0
                                door_confirmation = False
                                nearest_door = None
                                door_message = ""
                                room_instruction_timer = 0
                                freeze_timer = 0
                                door_prompt_timer = 0
                                try:
                                    play_sound("door")
                                except pygame.error:
                                    pass
                                if current_room.next_room:
                                    current_room = rooms[current_room.next_room]
                                    # Position player on the right-hand side when entering new room
                                    player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
                                    room_instruction = ROOM_INSTRUCTIONS[current_room.name]
                                    room_instruction_timer = MESSAGE_DURATION
                                    freeze_movement = True
                                    freeze_timer = MESSAGE_DURATION
                            else:
                                password_message = (
                                    f"Wrong password. You've clearly missed your daily mandatory 'synergy' meeting.\n"
                                    f"Hint: It's your name, not 'Adele'."
                                )
                                password_message_timer = MESSAGE_DURATION
                                password_cooldown = COOLDOWN_DURATION
                                password_input = ""
                                key_message_timer = 0
                                table_message_timer = 0
                                monitor_timer = 0
                                object_message_timer = 0
                                door_confirmation = False
                                nearest_door = None
                                door_message = ""
                                room_instruction_timer = 0
                                freeze_timer = 0
                                door_prompt_timer = 0
                        elif current_room.name == "boss_room":
                            if password_input.lower() == ROOM8_PASSWORD:
                                escaped = True
                                victory_message = (
                                    "Thank you for your 'contribution,' Adela.\n"
                                    "Unfortunately, we are out of budget, so you're fired.\n"
                                    "Your dedication was truly... inefficient.\n"
                                    "Now get out before you infect others with competence.\n"
                                    "You escaped! But at what cost?\n"
                                    "Freedom, perhaps... and unemployment.\n"
                                    "Press [Y] to restart."
                                )
                                show_end_screen = True
                                restart_confirm_window = True
                                password_mode = False
                                password_input = ""
                                password_message_timer = 0
                                password_cooldown = 0 # Reset cooldown after correct password
                                key_message_timer = 0
                                table_message_timer = 0
                                monitor_timer = 0
                                object_message_timer = 0
                                door_confirmation = False
                                nearest_door = None
                                door_message = ""
                                room_instruction_timer = 0
                                freeze_timer = 0
                                door_prompt_timer = 0
                                try:
                                    play_sound("escape_sound")
                                except pygame.error:
                                    pass
                            else:
                                trap_message = (
                                    "Can't believe you can't even get this one correct. Perhaps a career in 'optimization' isn't for you.\n"
                                    "Or any career at all. Game Over. Press [Y] to restart."
                                )
                                game_over = True
                                restart_confirm_window = True
                                password_mode = False
                                password_input = ""
                                password_message_timer = 0
                                key_message_timer = 0
                                table_message_timer = 0
                                monitor_timer = 0
                                object_message_timer = 0
                                door_confirmation = False
                                nearest_door = None
                                door_message = ""
                                room_instruction_timer = 0
                                freeze_timer = 0
                                door_prompt_timer = 0
                                try:
                                    play_sound("trap")
                                except pygame.error:
                                    pass
                    elif event.key == pygame.K_BACKSPACE:
                        password_input = password_input[:-1]
                    elif current_room.name == "boss_room" and pygame.K_a <= event.key <= pygame.K_d:
                        password_input = chr(event.key).lower()
                    elif current_room.name != "boss_room" and pygame.K_a <= event.key <= pygame.K_z:
                        password_input += chr(event.key).lower()
                # Handle Y/N input for monitor interaction when monitor_message is active
                elif (event.key == pygame.K_y or event.key == pygame.K_n) and monitor_timer > 0 and current_room.name == "meeting_room" and monitor_rect and player_rect.colliderect(monitor_rect):
                    if event.key == pygame.K_y:
                        monitor_on = True
                        monitor_message = (
                            "Luckily I still remember my login account is my name 'adela', though all my colleagues and bosses thought my name is 'adele'. Pathetic."
                        )
                        monitor_timer = MESSAGE_DURATION # Keep message up for duration
                    else: # event.key == pygame.K_n
                        monitor_on = False
                        monitor_message = "Monitor remains off. Some things are better left undisturbed." # Clear message
                        monitor_timer = MESSAGE_DURATION # Display for a bit then clear
                    # Clear other active messages after monitor interaction
                    password_mode = False
                    password_message_timer = 0
                    key_message_timer = 0
                    table_message_timer = 0
                    object_message_timer = 0
                    door_confirmation = False
                    nearest_door = None
                    door_message = ""
                    room_instruction_timer = 0
                    freeze_timer = 0
                    door_prompt_timer = 0
                elif event.key == pygame.K_i: # Toggle inventory
                    show_inventory = not show_inventory
                    # Clear all other messages when inventory is toggled
                    password_mode = False
                    password_message = ""
                    password_message_timer = 0
                    key_message = ""
                    key_message_timer = 0
                    table_message = ""
                    table_message_timer = 0
                    monitor_message = ""
                    monitor_timer = 0
                    object_message = ""
                    object_message_timer = 0
                    door_confirmation = False
                    nearest_door = None
                    door_message = ""
                    room_instruction_timer = 0
                    freeze_timer = 0
                    door_prompt_timer = 0 # Also clear this
                elif (event.key == pygame.K_y or event.key == pygame.K_n) and door_prompt_timer > 0 and nearest_door:
                    # Handle Y/N input for door confirmation when prompt is active
                    handle_door_confirmation(chr(event.key).lower())
                    # The handle_door_confirmation function will now manage resetting flags and timers

def handle_movement():
    """Handle player movement and object interactions (GDD Section 1)."""
    global game_state, screen, WIDTH, HEIGHT, inventory, has_key, password_mode, password_input, \
           password_message, password_message_timer, password_cooldown, key_message, key_message_timer, \
           table_message, table_message_timer, monitor_message, monitor_timer, monitor_on, \
           intern_message, object_message, object_message_timer, door_message, door_confirmation, nearest_door, \
           game_over, escaped, trap_message, victory_message, restart_confirm_window, show_end_screen, \
           room_instruction, room_instruction_timer, freeze_movement, freeze_timer, \
           blink_timer, flash_timer, show_inventory, player_x, player_y, \
           rubbish_objects, table_sets, data_center_objects, data_center_obstacles, \
           meeting_table, meeting_chairs, monitor_rect, server_rectangles, intern_x, intern_y, \
           pantry_circles, pantry_rectangles, secretary_table, secretary_chair_center, secretary_x, secretary_y, \
           intern_path, intern_path_index, current_room, door_prompt_timer # Add door_prompt_timer

    # Only allow movement if not frozen, not in password mode, not confirming door, and no room instruction is active
    if not show_end_screen and not game_over and not escaped and not freeze_movement and not password_mode and not door_confirmation and room_instruction_timer <= 0:
        keys = pygame.key.get_pressed()
        old_x, old_y = player_x, player_y

        if keys[pygame.K_LEFT]:
            player_x -= PLAYER_SPEED
        if keys[pygame.K_RIGHT]:
            player_x += PLAYER_SPEED
        if keys[pygame.K_UP]:
            player_y -= PLAYER_SPEED
        if keys[pygame.K_DOWN]:
            player_y += PLAYER_SPEED
        
        player_x = float(player_x)
        player_y = float(player_y)

        player_rect = pygame.Rect(
            int(player_x - PLAYER_WIDTH // 2),
            int(player_y - PLAYER_HEIGHT // 2),
            PLAYER_WIDTH,
            PLAYER_HEIGHT,
        )

        # Wall collisions (using current WIDTH and HEIGHT)
        if (
            player_x - PLAYER_WIDTH // 2 < 10
            or player_x + PLAYER_WIDTH // 2 > WIDTH - 10
            or player_y - PLAYER_HEIGHT // 2 < 10
            or player_y + PLAYER_HEIGHT // 2 > HEIGHT - 110 - 10
        ):
            player_x, player_y = old_x, old_y

        # Door collision (using current_room object and current WIDTH, HEIGHT)
        # Check if player collides with a door AND no other message/interaction is active
        if not door_confirmation and not password_mode and not monitor_timer > 0 and not object_message_timer > 0 and not table_message_timer > 0 and not key_message_timer > 0 and not room_instruction_timer > 0:
            current_door_type, is_trap, is_inaccessible = check_door_collision(player_rect, current_room, WIDTH, HEIGHT)
            if current_door_type:
                # When a door is collided with, display the prompt and freeze movement
                door_message = "Enter Room? [Y]/[N]"
                door_confirmation = True
                nearest_door = (current_door_type, is_trap, is_inaccessible)
                door_prompt_timer = MESSAGE_DURATION # Set a timer for the prompt
                freeze_movement = True # Freeze player movement

        # Intern movement in server room
        if current_room.name == "server_room" and intern_path:
            # Calculate distance to current target
            target_x, target_y = intern_path[intern_path_index]
            dx = target_x - intern_x
            dy = target_y - intern_y
            distance = (dx * dx + dy * dy) ** 0.5

            # Move intern towards target
            if distance > INTERN_SPEED:
                # Normalize direction and apply speed
                intern_x += (dx / distance) * INTERN_SPEED
                intern_y += (dy / distance) * INTERN_SPEED
            else:
                # Reached target, move to next point
                intern_path_index = (intern_path_index + 1) % len(intern_path)

            # Check for collision with player
            intern_rect = pygame.Rect(
                int(intern_x - INTERN_RADIUS),
                int(intern_y - INTERN_RADIUS),
                INTERN_RADIUS * 2,
                INTERN_RADIUS * 2
            )
            if intern_rect.colliderect(player_rect):
                game_over = True
                trap_message = "The intern caught you! Your career is over."
                show_end_screen = True

        # Room-specific interactions
        if current_room.name == "coding_cubicle":
            for i, (obj_x, obj_y, obj_name, is_key, collected) in enumerate(rubbish_objects):
                if not collected:
                    obj_rect = pygame.Rect(
                        int(obj_x - RUBBISH_RADIUS),
                        int(obj_y - RUBBISH_RADIUS),
                        RUBBISH_RADIUS * 2,
                        RUBBISH_RADIUS * 2,
                    )
                    if player_rect.colliderect(obj_rect):
                        item_key = obj_name
                        found = False
                        for j, item in enumerate(inventory):
                            if item.startswith(item_key):
                                current_count = int(item.split(' x ')[1]) if ' x ' in item else 1
                                inventory[j] = f"{item_key} x {current_count + 1}"
                                found = True
                                break
                        if not found:
                            inventory.append(f"{item_key} x 1")
                        rubbish_objects[i] = (obj_x, obj_y, obj_name, is_key, True)
                        object_message = f"You got {item_key}! Hope it's worth the existential dread."
                        object_message_timer = MESSAGE_DURATION
                        # Clear other active messages when new object message appears
                        password_mode = False
                        password_message_timer = 0
                        key_message_timer = 0
                        table_message_timer = 0
                        monitor_timer = 0
                        door_confirmation = False # Clear door prompt state
                        nearest_door = None
                        door_message = ""
                        room_instruction_timer = 0
                        freeze_timer = 0
                        door_prompt_timer = 0
                        try:
                            play_sound("treasure")
                        except pygame.error:
                            pass
                        if is_key:
                            has_key = True
                        flash_timer = 15

            for i, (table_rect, chair_center) in enumerate(table_sets):
                chair_rect = pygame.Rect(
                    int(chair_center[0] - CHAIR_RADIUS),
                    int(chair_center[1] - CHAIR_RADIUS),
                    CHAIR_RADIUS * 2,
                    CHAIR_RADIUS * 2
                )
                if player_rect.colliderect(table_rect) or player_rect.colliderect(chair_rect):
                    player_x, player_y = old_x, old_y
                    table_messages = [
                        "It's Mary… She just got fired. Guess her Jira tickets weren't up to standard.",
                        "This cubicle smells of burnt ambition and instant noodles. Just another Monday.",
                        "Someone left their soul here. Probably for a pizza party that never happened.",
                        "Don't mind Kevin. He's been staring at that blank screen since Tuesday. A true corporate zombie.",
                        "The coffee stains here tell a story of countless late nights and questionable life choices.",
                        "Another empty chair. Probably someone's 'sick day' that turned into a 'new career' day.",
                        "This keyboard still has crumbs from last year's holiday party. Quality assurance is key.",
                        "Look, another motivational poster! 'Teamwork makes the dream work!' If only the dream wasn't perpetual exhaustion.",
                        "Is that a cobweb? Or just a metaphor for the company's progress?",
                        "The air here is thick with the scent of unread emails and existential dread.",
                        "Someone's forgotten lunch has achieved sentience. It's probably happier than its owner.",
                        "This cubicle survived a reorg. It's seen things. Horrible, spreadsheet-related things."
                    ]
                    table_message = table_messages[i % len(table_messages)]
                    table_message_timer = MESSAGE_DURATION
                    # Clear other active messages when new table message appears
                    password_mode = False
                    password_message_timer = 0
                    key_message_timer = 0
                    monitor_timer = 0
                    object_message_timer = 0
                    door_confirmation = False # Clear door prompt state
                    nearest_door = None
                    door_message = ""
                    room_instruction_timer = 0
                    freeze_timer = 0
                    door_prompt_timer = 0
        elif current_room.name == "data_center":
            for i, (obj_x, obj_y, obj_name, _, collected) in enumerate(data_center_objects):
                if not collected:
                    obj_rect = pygame.Rect(
                        int(obj_x - RUBBISH_RADIUS),
                        int(obj_y - RUBBISH_RADIUS),
                        RUBBISH_RADIUS * 2,
                        RUBBISH_RADIUS * 2,
                    )
                    if player_rect.colliderect(obj_rect):
                        item_key = obj_name
                        found = False
                        for j, item in enumerate(inventory):
                            if item.startswith(item_key):
                                current_count = int(item.split(' x ')[1]) if ' x ' in item else 1
                                inventory[j] = f"{item_key} x {current_count + 1}"
                                found = True
                                break
                        if not found:
                            inventory.append(f"{item_key} x 1")
                        data_center_objects[i] = (obj_x, obj_y, obj_name, False, True)
                        object_message = f"You got {item_key}! Hope it's worth the existential dread."
                        object_message_timer = MESSAGE_DURATION
                        # Clear other active messages
                        password_mode = False
                        password_message_timer = 0
                        key_message_timer = 0
                        table_message_timer = 0
                        monitor_timer = 0
                        door_confirmation = False # Clear door prompt state
                        nearest_door = None
                        door_message = ""
                        room_instruction_timer = 0
                        freeze_timer = 0
                        door_prompt_timer = 0
                        try:
                            play_sound("treasure")
                        except pygame.error:
                            pass
                        flash_timer = 15
            for rect in data_center_obstacles:
                if rect.colliderect(player_rect):
                    player_x, player_y = old_x, old_y
        elif current_room.name == "meeting_room":
            if meeting_table and player_rect.colliderect(meeting_table):
                player_x, player_y = old_x, old_y
            for chair_center in meeting_chairs:
                chair_rect = pygame.Rect(
                    int(chair_center[0] - CHAIR_RADIUS),
                    int(chair_center[1] - CHAIR_RADIUS),
                    CHAIR_RADIUS * 2,
                    CHAIR_RADIUS * 2
                )
                if player_rect.colliderect(chair_rect):
                    player_x, player_y = old_x, old_y
            # Monitor interaction: condition check is robust, logic for turning on and messages should work
            if monitor_rect and player_rect.colliderect(monitor_rect) and monitor_timer <= 0 and not monitor_message and not door_confirmation and not password_mode:
                monitor_message = "Turn on the monitor? [Y] = Yes, [N] = No"
                monitor_timer = MESSAGE_DURATION # Set a timer for the prompt
                # No monitor_on = True here, it's set on Y press.
                # Clear other active messages
                password_mode = False
                password_message_timer = 0
                key_message_timer = 0
                table_message_timer = 0
                object_message_timer = 0
                door_confirmation = False # Clear door prompt state if active
                nearest_door = None
                door_message = ""
                room_instruction_timer = 0
                freeze_timer = 0
                door_prompt_timer = 0 # Ensure door prompt is cleared
                try:
                    play_sound("treasure")
                except pygame.error:
                    pass
        elif current_room.name == "server_room":
            if intern_x is not None and intern_y is not None and intern_path: # Ensure intern_path is not empty
                target_x, target_y = intern_path[intern_path_index]
                dx = target_x - intern_x
                dy = target_y - intern_y
                dist = (dx**2 + dy**2)**0.5
                if dist > INTERN_SPEED:
                    intern_x += dx * INTERN_SPEED / dist
                    intern_y += dy * INTERN_SPEED / dist
                else:
                    intern_x, intern_y = target_x, target_y
                    intern_path_index = (intern_path_index + 1) % len(intern_path)
                
                intern_rect = pygame.Rect(
                    int(intern_x - INTERN_RADIUS),
                    int(intern_y - INTERN_RADIUS),
                    INTERN_RADIUS * 2,
                    INTERN_RADIUS * 2,
                )
                if player_rect.colliderect(intern_rect):
                    intern_message = "You meet the trouble maker, our intern—Mike. Game Over. He always finds a way to break things."
                    game_over = True
                    restart_confirm_window = True
                    # Clear all other active messages
                    password_mode = False
                    password_message_timer = 0
                    key_message_timer = 0
                    table_message_timer = 0
                    monitor_timer = 0
                    object_message_timer = 0
                    door_confirmation = False # Clear door prompt state
                    nearest_door = None
                    door_message = ""
                    room_instruction_timer = 0
                    freeze_timer = 0
                    door_prompt_timer = 0
                    try:
                        play_sound("trap")
                    except pygame.error:
                        pass
            for rect in server_rectangles:
                if rect.colliderect(player_rect):
                    player_x, player_y = old_x, old_y
        elif current_room.name == "pantry":
            for rect in pantry_rectangles:
                if rect.colliderect(player_rect):
                    player_x, player_y = old_x, old_y
            for i, (circle_x, circle_y, collected) in enumerate(pantry_circles):
                if not collected:
                    circle_rect = pygame.Rect(
                        int(circle_x - RUBBISH_RADIUS),
                        int(circle_y - RUBBISH_RADIUS),
                        RUBBISH_RADIUS * 2,
                        RUBBISH_RADIUS * 2,
                    )
                    if player_rect.colliderect(circle_rect):
                        item_key = "instant coffee stick"
                        found = False
                        for j, item in enumerate(inventory):
                            if item.startswith(item_key):
                                current_count = int(item.split(' x ')[1]) if ' x ' in item else 1
                                inventory[j] = f"{item_key} x {current_count + 1}"
                                found = True
                                break
                        if not found:
                            inventory.append(f"{item_key} x 1")
                        pantry_circles[i] = (circle_x, circle_y, True)
                        object_message = f"You got {item_key}! Hope it's worth the existential dread."
                        object_message_timer = MESSAGE_DURATION
                        # Clear other active messages
                        password_mode = False
                        password_message_timer = 0
                        key_message_timer = 0
                        table_message_timer = 0
                        monitor_timer = 0
                        door_confirmation = False # Clear door prompt state
                        nearest_door = None
                        door_message = ""
                        room_instruction_timer = 0
                        freeze_timer = 0
                        door_prompt_timer = 0
                        try:
                            play_sound("treasure")
                        except pygame.error:
                            pass
                        flash_timer = 15
        elif current_room.name == "secretary_room":
            if secretary_table and player_rect.colliderect(secretary_table):
                player_x, player_y = old_x, old_y
            secretary_chair_rect = pygame.Rect(
                int(secretary_chair_center[0] - CHAIR_RADIUS),
                int(secretary_chair_center[1] - CHAIR_RADIUS),
                CHAIR_RADIUS * 2,
                CHAIR_RADIUS * 2
            )
            if player_rect.colliderect(secretary_chair_rect):
                player_x, player_y = old_x, old_y

            secretary_npc_rect = pygame.Rect(
                int(secretary_x - SECRETARY_RADIUS),
                int(secretary_y - SECRETARY_RADIUS),
                SECRETARY_RADIUS * 2,
                SECRETARY_RADIUS * 2,
            )
            if secretary_npc_rect.colliderect(player_rect) and table_message_timer <=0 :
                table_message = (
                    f"Hey, the boss wants to have a meeting with you. Good luck, you'll need it. "
                    "I'd rather staple my hand to a spreadsheet."
                )
                table_message_timer = MESSAGE_DURATION
                # Clear other active messages
                password_mode = False
                password_message_timer = 0
                key_message_timer = 0
                monitor_timer = 0
                object_message_timer = 0
                door_confirmation = False # Clear door prompt state
                nearest_door = None
                door_message = ""
                room_instruction_timer = 0
                freeze_timer = 0
                door_prompt_timer = 0
                try:
                    play_sound("treasure")
                except pygame.error:
                    pass
        elif current_room.name == "boss_room":
            password_mode = True
            password_message = (
                "Adela, pick the best deadline excuse:\n"
                "A) 'Cat ate the drive.'\n"
                "B) 'Synergy overload.'\n"
                "C) 'Too productive.'\n"
                "D) 'Work-life training.'"
            )
            password_message_timer = PASSWORD_DURATION
            # Use tiny font for boss message
            global password_font
            password_font = TINY_FONT
            # Clear other active messages
            key_message_timer = 0
            table_message_timer = 0
            monitor_timer = 0
            object_message_timer = 0
            door_confirmation = False # Clear door prompt state
            nearest_door = None
            door_message = ""
            room_instruction_timer = 0
            freeze_timer = 0
            door_prompt_timer = 0

        # Check collision with secretary in secretary room
        if current_room.name == "secretary_room":
            secretary_rect = pygame.Rect(
                int(secretary_x - SECRETARY_RADIUS),
                int(secretary_y - SECRETARY_RADIUS),
                SECRETARY_RADIUS * 2,
                SECRETARY_RADIUS * 2
            )
            if player_rect.colliderect(secretary_rect):
                return

        # Check boss collision
        if current_room.name == "boss_room":
            boss_rect = pygame.Rect(
                int(WIDTH // 2 - BOSS_RADIUS),
                int(HEIGHT // 3 - BOSS_RADIUS),
                BOSS_RADIUS * 2,
                BOSS_RADIUS * 2
            )
            if player_rect.colliderect(boss_rect):
                password_mode = True
                password_message = "What is the password?"
                password_input = ""
                # Don't set door_message here, let the conversation box show "I'm so nervous..."

        # Check collision with intern in server room
        if current_room.name == "server_room":
            intern_rect = pygame.Rect(
                int(intern_x - INTERN_RADIUS),
                int(intern_y - INTERN_RADIUS),
                INTERN_RADIUS * 2,
                INTERN_RADIUS * 2
            )
            if player_rect.colliderect(intern_rect):
                return

def update_timers():
    """Update all game timers (GDD Section 1)."""
    global freeze_timer, freeze_movement, room_instruction_timer, key_message_timer
    global password_message_timer, table_message_timer, password_cooldown, monitor_timer
    global object_message_timer, blink_timer, flash_timer, door_prompt_timer, door_confirmation, door_message, nearest_door
    
    freeze_timer = max(0, freeze_timer - 1)
    # Only unfreeze if no other blocking message/interaction is active
    if freeze_timer == 0 and not door_confirmation and not password_mode and not monitor_timer > 0 and not object_message_timer > 0 and not table_message_timer > 0 and not key_message_timer > 0 and not room_instruction_timer > 0: # Added room_instruction_timer check
        freeze_movement = False

    room_instruction_timer = max(0, room_instruction_timer - 1)
    key_message_timer = max(0, key_message_timer - 1)
    table_message_timer = max(0, table_message_timer - 1)
    password_message_timer = max(0, password_message_timer - 1)
    password_cooldown = max(0, password_cooldown - 1)
    monitor_timer = max(0, monitor_timer - 1)
    object_message_timer = max(0, object_message_timer - 1)
    
    door_prompt_timer = max(0, door_prompt_timer - 1)
    # If the door prompt timer expires, clear the state and unfreeze movement
    if door_prompt_timer == 0 and door_confirmation:
        door_confirmation = False
        door_message = ""
        nearest_door = None
        freeze_movement = False # Allow movement again


    blink_timer = (blink_timer + 1) % 20

    flash_timer = max(0, flash_timer - 1)

async def main_loop():
    """Main game loop (GDD Section 1)."""
    global game_state, current_room, player_x, player_y, room_instruction, password_mode, music_playing, \
           room_instruction_timer, freeze_movement, freeze_timer, WIDTH, HEIGHT, game_over, escaped, show_end_screen, \
           inventory, rubbish_objects, table_sets, data_center_objects, data_center_obstacles, meeting_table, \
           meeting_chairs, monitor_rect, server_rectangles, intern_x, intern_y, pantry_rectangles, pantry_circles, \
           secretary_table, secretary_chair_center, secretary_x, secretary_y, intern_path_index, has_key, \
           password_input, password_message, password_message_timer, password_cooldown, key_message, key_message_timer, \
           table_message, table_message_timer, monitor_message, monitor_timer, intern_message, object_message, \
           object_message_timer, trap_message, victory_message, restart_confirm_window, blink_timer, flash_timer, \
           door_message, door_confirmation, nearest_door, door_prompt_timer, show_inventory, inventory_prompt, rooms, intern_path

    try:
        while True:
            if game_state == GAME_STATE_START:
                # show_start_screen handles its own loop and returns True when SPACE is pressed
                if show_start_screen(screen, MEDIUM_FONT, SMALL_FONT): # Pass MEDIUM_FONT to start screen for prompt
                    game_state = GAME_STATE_PLAY
                    # Re-initialize all necessary game state variables upon starting a new game
                    # Pass WIDTH, HEIGHT to setup_rooms
                    rooms = setup_rooms(WIDTH, HEIGHT)
                    current_room = rooms["lobby"]
                    # Updated initial player position for lobby to be in front of the right door
                    player_x, player_y = (WIDTH - DOOR_WIDTH) - PLAYER_WIDTH - 10, (HEIGHT // 2 - DOOR_WIDTH // 2) + DOOR_WIDTH // 2
                    inventory.clear()
                    has_key = False
                    password_mode = False
                    password_input = ""
                    password_message = ""
                    password_message_timer = 0
                    password_cooldown = 0
                    key_message = ""
                    key_message_timer = 0
                    table_message = ""
                    table_message_timer = 0
                    monitor_message = ""
                    monitor_timer = 0
                    monitor_on = False
                    intern_message = ""
                    object_message = ""
                    object_message_timer = 0
                    game_over = False
                    escaped = False
                    trap_message = ""
                    victory_message = ""
                    restart_confirm_window = False
                    room_instruction = ROOM_INSTRUCTIONS[current_room.name]
                    room_instruction_timer = MESSAGE_DURATION
                    freeze_movement = True
                    freeze_timer = MESSAGE_DURATION
                    blink_timer = 0
                    flash_timer = 0
                    door_message = ""
                    door_confirmation = False
                    nearest_door = None
                    door_prompt_timer = 0 # Reset door prompt timer on start
                    show_end_screen = False
                    music_playing = False # Ensure music is marked as not playing to allow restart
                    show_inventory = False
                    inventory_prompt = "Inventory = [I]"

                    # Re-setup all game objects, passing current WIDTH, HEIGHT
                    rubbish_objects, table_sets = setup_rubbish_and_tables(WIDTH, HEIGHT)
                    data_center_objects, data_center_obstacles = setup_data_center_objects(WIDTH, HEIGHT)
                    meeting_table, meeting_chairs, monitor_rect = setup_meeting_room_objects(WIDTH, HEIGHT)
                    # Correctly capture intern_path from setup_server_room_objects
                    server_rectangles, intern_x, intern_y, intern_path = setup_server_room_objects(WIDTH, HEIGHT)
                    pantry_rectangles, pantry_circles = setup_pantry_room(WIDTH, HEIGHT)
                    secretary_table, secretary_chair_center, secretary_x, secretary_y = setup_secretary_room_objects(WIDTH, HEIGHT)
                    intern_path_index = 0

                    if not music_playing:
                        try:
                            play_background_music()
                            music_playing = True
                        except pygame.error as e:
                            print(f"Error playing background music: {e}")
                            pass
            
            if game_state == GAME_STATE_PLAY:
                handle_events()
                handle_movement()
                update_timers()

                if show_end_screen or game_over:
                    screen.fill(BLACK)
                    display_text = victory_message if show_end_screen else trap_message
                    lines = display_text.split("\n")
                    try:
                        for i, line in enumerate(lines):
                            # Use SMALL_FONT for end screen messages (trap/victory)
                            text_surface = SMALL_FONT.render(line, True, WHITE)
                            text_rect = text_surface.get_rect(center=(WIDTH // 2, HEIGHT // 4 + i * 50))
                            screen.blit(text_surface, text_rect)
                    except Exception as e:
                        print(f"Error rendering end screen: {e}")
                else:
                    try:
                        render_game(
                            screen=screen,
                            current_room=current_room,
                            player_x=player_x,
                            player_y=player_y,
                            inventory=inventory,
                            rubbish_objects=rubbish_objects,
                            table_sets=table_sets,
                            data_center_objects=data_center_objects,
                            data_center_obstacles=data_center_obstacles,
                            meeting_room_table=meeting_table,
                            meeting_chairs=meeting_chairs,
                            monitor_rect=monitor_rect,
                            server_rectangles=server_rectangles,
                            intern_x=intern_x,
                            intern_y=intern_y,
                            pantry_rectangles=pantry_rectangles,
                            pantry_circles=pantry_circles,
                            secretary_table=secretary_table,
                            secretary_chair_center=secretary_chair_center,
                            secretary_x=secretary_x,
                            secretary_y=secretary_y,
                            door_confirmation=door_confirmation,
                            nearest_door=nearest_door,
                            key_message=key_message,
                            key_message_timer=key_message_timer,
                            password_mode=password_mode,
                            password_message=password_message,
                            password_input=password_input,
                            password_message_timer=password_message_timer,
                            table_message=table_message,
                            table_message_timer=table_message_timer,
                            monitor_message=monitor_message,
                            monitor_timer=monitor_timer,
                            intern_message=intern_message,
                            object_message=object_message,
                            object_message_timer=object_message_timer,
                            game_over=game_over,
                            escaped=escaped,
                            trap_message=trap_message,
                            victory_message=victory_message,
                            restart_confirm_window=restart_confirm_window,
                            room_instruction=room_instruction,
                            room_instruction_timer=room_instruction_timer,
                            blink_timer=blink_timer,
                            flash_timer=flash_timer,
                            door_message=door_message,
                            show_end_screen=show_end_screen,
                            monitor_on=monitor_on,
                            show_inventory=show_inventory,
                            inventory_prompt=inventory_prompt,
                            medium_font_obj=MEDIUM_FONT,
                            small_font_obj=SMALL_FONT,
                            tiny_font_obj=TINY_FONT, # Passed standardized font name
                            width=WIDTH,
                            height=HEIGHT
                        )
                    except Exception as e:
                        print(f"Error in render_game: {e}")
            
            pygame.display.flip()
            clock.tick(FPS)
            await asyncio.sleep(1.0 / FPS)
    except Exception as e:
        print(f"Unexpected error in main_loop: {e}")
        raise
    finally:
        stop_background_music()
        pygame.quit()
        sys.exit()

if platform.system() == "Emscripten":
    asyncio.ensure_future(main_loop())
else:
    if __name__ == "__main__":
        asyncio.run(main_loop())
