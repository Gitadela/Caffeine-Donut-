import pygame
import random
import math
from typing import Tuple, List
# Import specific constants needed, excluding WIDTH and HEIGHT
from constants import (
    RUBBISH_RADIUS, TABLE_WIDTH, TABLE_HEIGHT, CHAIR_RADIUS,
    DATA_CENTER_RECT_WIDTH, DATA_CENTER_RECT_HEIGHT, MEETING_TABLE_WIDTH,
    MEETING_TABLE_HEIGHT, DOOR_WIDTH, PLAYER_WIDTH, SECRETARY_RADIUS # Added SECRETARY_RADIUS for secretary calculations
)

def setup_rubbish_and_tables(width: int, height: int):
    """Set up rubbish objects and table/chair sets for coding_cubicle (GDD Section 5).
       Accepts dynamic width and height.
       Ensures objects maintain sufficient space from user's initial position."""
    try:
        rubbish_objects = []
        
        # Table/chair sets in a 3x4 grid, regularly placed
        table_sets = []
        grid_rows = 3
        grid_cols = 4
        
        # Adjust margins for sufficient spacing from player entry (initial player_x is around width - 50)
        margin_x = 100 # Increased from 70px for better clearance
        margin_y = 70
        
        spacing_x = (width - 2 * margin_x - grid_cols * TABLE_WIDTH) // (grid_cols - 1) if grid_cols > 1 else 0
        spacing_y = (height - 110 - 2 * margin_y - grid_rows * TABLE_HEIGHT) // (grid_rows - 1) if grid_rows > 1 else 0

        # Collectible items (rubbish and key)
        all_items = [
            "paperclip", "staple", "rubber band", "pen cap",
            "half donut", "moldy coffee cup", "half donut", "moldy coffee cup",
            "paperclip", "staple", "rubber band" # More rubbish items for balance
        ]
        random.shuffle(all_items) # Randomize item order

        # Add the key at a random table
        key_table_row = random.randint(0, grid_rows - 1)
        key_table_col = random.randint(0, grid_cols - 1)
        
        item_index = 0
        for row in range(grid_rows):
            for col in range(grid_cols):
                table_x = margin_x + col * (TABLE_WIDTH + spacing_x)
                table_y = margin_y + row * (TABLE_HEIGHT + spacing_y)
                table_rect = pygame.Rect(table_x, table_y, TABLE_WIDTH, TABLE_HEIGHT)
                
                # Chair position relative to table (on the longer side, at the bottom)
                chair_center_x = table_x + TABLE_WIDTH // 2
                chair_center_y = table_y + TABLE_HEIGHT + CHAIR_RADIUS + 5 # 5px padding from table
                chair_center = (chair_center_x, chair_center_y)
                
                table_sets.append((table_rect, chair_center))

                # Place collectible item on the right side of the table
                if row == key_table_row and col == key_table_col:
                    item_name = "key"
                    is_key = True
                else:
                    item_name = all_items[item_index % len(all_items)] # Cycle through rubbish types
                    is_key = False
                    item_index += 1
                
                # Place item slightly to the right of the table, ensuring accessibility
                item_x = table_x + TABLE_WIDTH + RUBBISH_RADIUS + 10 # Offset from table
                item_y = table_y + TABLE_HEIGHT // 2
                rubbish_objects.append((item_x, item_y, item_name, is_key, False)) # False for collected

        return rubbish_objects, table_sets
    except Exception as e:
        print(f"Error in setup_rubbish_and_tables: {e}")
        return [], []

def setup_data_center_objects(width: int, height: int):
    """Set up data_center objects (GDD Section 5), using dynamic width and height.
       Obstacles are placed to ensure clear player movement.
       Ensures objects maintain sufficient space from user's initial position."""
    try:
        obstacles = []
        collectibles = []

        grid_rows = 2
        grid_cols = 3
        
        obstacle_width = 70
        obstacle_height = 120

        # Define minimum path clearances
        min_horizontal_path = PLAYER_WIDTH * 3 # Very wide path horizontally
        min_vertical_path = PLAYER_WIDTH * 2   # Sufficient vertical path

        # Calculate total required width/height for obstacles + minimum paths
        required_total_width = (grid_cols * obstacle_width) + ((grid_cols - 1) * min_horizontal_path)
        required_total_height = (grid_rows * obstacle_height) + ((grid_rows - 1) * min_vertical_path)

        # Calculate margins to center the entire grid, ensuring space from walls
        outer_margin = 100 # Increased from 80px for better clearance
        margin_x = (width - required_total_width) // 2
        margin_y = (height - 110 - required_total_height) // 2 # Account for chatbox

        # Ensure margins are at least a certain value (e.g., 20 pixels)
        margin_x = max(20, margin_x)
        margin_y = max(20, margin_y)

        # Now place obstacles based on these margins and clearances
        for row in range(grid_rows):
            for col in range(grid_cols):
                # Calculate x position: margin + (col * obstacle_width) + (col * min_horizontal_path)
                obstacle_x = margin_x + (col * obstacle_width) + (col * min_horizontal_path)
                obstacle_y = margin_y + (row * obstacle_height) + (row * min_vertical_path)
                
                obstacle_rect = pygame.Rect(obstacle_x, obstacle_y, obstacle_width, obstacle_height)
                obstacles.append(obstacle_rect)

                # Place collectibles (broken mice) in the center of the path *below* the obstacle
                collectible_x = obstacle_x + obstacle_width // 2
                # Place slightly below the obstacle, ensuring it's in the clear path
                collectible_y = obstacle_y + obstacle_height + (min_vertical_path // 2) # Center in the vertical aisle
                collectibles.append((collectible_x, collectible_y, "broken mouse", False, False))

        return collectibles, obstacles
    except Exception as e:
        print(f"Error in setup_data_center_objects: {e}")
        return [], []


def setup_meeting_room_objects(width: int, height: int) -> Tuple[pygame.Rect, List[Tuple[int, int]], pygame.Rect]:
    """Setup meeting room objects (GDD Section 3)."""
    # Scale up the meeting table significantly
    scaled_table_width = int(MEETING_TABLE_WIDTH * 2)  # Doubled width
    scaled_table_height = int(MEETING_TABLE_HEIGHT * 2)  # Doubled height
    
    # Center the table in the room
    table_x = width // 2 - scaled_table_width // 2
    table_y = height // 2 - scaled_table_height // 2
    meeting_table = pygame.Rect(table_x, table_y, scaled_table_width, scaled_table_height)
    
    # Add more chairs around the table
    meeting_chairs = []
    # Top row of chairs (6 chairs)
    for i in range(6):
        chair_x = table_x + (scaled_table_width * (i + 1) // 7)
        chair_y = table_y - CHAIR_RADIUS - 10
        meeting_chairs.append((chair_x, chair_y))
    
    # Bottom row of chairs (6 chairs)
    for i in range(6):
        chair_x = table_x + (scaled_table_width * (i + 1) // 7)
        chair_y = table_y + scaled_table_height + CHAIR_RADIUS + 10
        meeting_chairs.append((chair_x, chair_y))
    
    # Left side chairs (4 chairs)
    for i in range(4):
        chair_x = table_x - CHAIR_RADIUS - 10
        chair_y = table_y + (scaled_table_height * (i + 1) // 5)
        meeting_chairs.append((chair_x, chair_y))
    
    # Right side chairs (4 chairs)
    for i in range(4):
        chair_x = table_x + scaled_table_width + CHAIR_RADIUS + 10
        chair_y = table_y + (scaled_table_height * (i + 1) // 5)
        meeting_chairs.append((chair_x, chair_y))
    
    # Add monitor above the table
    monitor_height = 40  # Fixed height for monitor
    monitor_rect = pygame.Rect(10, 10, width - 20, monitor_height)  # Spans wall-to-wall, 10px from top wall
    
    return meeting_table, meeting_chairs, monitor_rect


def setup_server_room_objects(width: int, height: int):
    """Set up server_room objects (GDD Section 5), using dynamic width and height.
       Obstacles are sized to not completely block user's path.
       Ensures objects maintain sufficient space from user's initial position."""
    try:
        rectangles = []
        grid_rows = 5
        grid_cols = 3

        # Define obstacle dimensions for vertical rectangles - RECONSIDERED SIZE for clear paths
        obstacle_width = 20  # Reduced from 30 to 20
        obstacle_height = 40  # Reduced from 60 to 40

        # Calculate margins and spacing
        # Increased margins for better clearance from player entry (initial player_x is around width - 50)
        margin_x = 100 
        margin_y = 100 
        
        # Calculate available space for grid, considering margins
        available_width = width - 2 * margin_x
        available_height = height - 110 - 2 * margin_y  # Account for conversation box height

        # Calculate spacing for obstacles
        # Ensure minimum path width for player to move through
        min_path_clearance = PLAYER_WIDTH * 2  # Increased from 1.5 to 2 for better clearance

        # Calculate horizontal spacing
        calculated_spacing_x = (available_width - grid_cols * obstacle_width) // (grid_cols - 1) if grid_cols > 1 else 0
        spacing_x = max(calculated_spacing_x, min_path_clearance)

        # Calculate vertical spacing
        calculated_spacing_y = (available_height - grid_rows * obstacle_height) // (grid_rows - 1) if grid_rows > 1 else 0
        spacing_y = max(calculated_spacing_y, min_path_clearance)

        # Recalculate if spacing adjustment pushed obstacles out of bounds
        # This is a common issue with `max` on spacing. Let's ensure fixed total width/height.
        # Instead, dynamically calculate obstacle count or margin if space is limited.
        # For this, let's assume we can fit 3x5 and ensure path.
        # Recalculate margins based on desired spacing to ensure it fits:
        total_obstacles_width = grid_cols * obstacle_width + (grid_cols - 1) * spacing_x
        total_obstacles_height = grid_rows * obstacle_height + (grid_rows - 1) * spacing_y
        
        # Adjust margins to center the grid if it's smaller than available space
        current_margin_x = (width - total_obstacles_width) // 2
        current_margin_y = (height - 110 - total_obstacles_height) // 2  # Account for chatbox

        # Ensure margins are at least 10 for wall clearance, use current_margin_x/y if larger
        final_margin_x = max(10, current_margin_x)
        final_margin_y = max(10, current_margin_y)

        for row in range(grid_rows):
            for col in range(grid_cols):
                rect_x = final_margin_x + col * (obstacle_width + spacing_x)
                rect_y = final_margin_y + row * (obstacle_height + spacing_y)
                rectangles.append(pygame.Rect(rect_x, rect_y, obstacle_width, obstacle_height))

        # Intern's initial position
        # Position intern away from player's entry point (right side)
        intern_x = width // 2 - 150  # Moved left from center for better initial spacing
        intern_y = height // 2 + 100

        # Define intern_path relative to WIDTH and HEIGHT for scalability
        # Path points are now placed in the spaces between obstacles, following a more human-like route
        intern_path = [
            # Start from left side, move through gaps
            (final_margin_x + spacing_x // 2, final_margin_y + spacing_y // 2),  # Start at top-left gap
            (final_margin_x + spacing_x // 2, final_margin_y + obstacle_height + spacing_y * 1.5),  # Move down to middle-left gap
            (final_margin_x + obstacle_width + spacing_x * 1.5, final_margin_y + obstacle_height + spacing_y * 1.5),  # Move right to middle-middle gap
            (final_margin_x + obstacle_width + spacing_x * 1.5, final_margin_y + spacing_y // 2),  # Move up to top-middle gap
            (final_margin_x + obstacle_width * 2 + spacing_x * 2.5, final_margin_y + spacing_y // 2),  # Move right to top-right gap
            (final_margin_x + obstacle_width * 2 + spacing_x * 2.5, final_margin_y + obstacle_height + spacing_y * 1.5),  # Move down to middle-right gap
            (final_margin_x + obstacle_width * 2 + spacing_x * 2.5, final_margin_y + obstacle_height * 2 + spacing_y * 2.5),  # Move down to bottom-right gap
            (final_margin_x + obstacle_width + spacing_x * 1.5, final_margin_y + obstacle_height * 2 + spacing_y * 2.5),  # Move left to bottom-middle gap
            (final_margin_x + spacing_x // 2, final_margin_y + obstacle_height * 2 + spacing_y * 2.5),  # Move left to bottom-left gap
            (final_margin_x + spacing_x // 2, final_margin_y + spacing_y // 2),  # Return to start
        ]
        
        return rectangles, intern_x, intern_y, intern_path
    except Exception as e:
        print(f"Error in setup_server_room_objects: {e}")
        return [], 0, 0, []

def setup_pantry_room(width: int, height: int):
    """Set up pantry objects (GDD Section 5), using dynamic width and height.
       Ensures objects maintain sufficient space from user's initial position."""
    try:
        # Form a square rectangle with entry/exit in the middle of the room
        square_size = min(width, height - 110) * 0.6 # Make it responsive to screen size
        
        # Adjust square_x for clearance from right wall (player entry point)
        square_x = (width - square_size) // 2
        if square_x + square_size > width - 100: # 100px clearance
            square_x = width - 100 - square_size

        square_y = (height - 110 - square_size) // 2 # Account for conversation box

        # Revised pantry structure rectangles to include gaps for entry/exit points
        # Gaps are intentional per GDD for "two entry/exit points on the right and left for user navigation"
        new_rectangles = []
        
        # Top wall
        new_rectangles.append(pygame.Rect(square_x, square_y, square_size, 20))
        # Bottom wall
        new_rectangles.append(pygame.Rect(square_x, square_y + square_size - 20, square_size, 20))

        # Calculate segment lengths for left/right walls with a gap in the middle
        gap_y_start = square_y + square_size // 2 - DOOR_WIDTH // 2
        gap_height = DOOR_WIDTH
        
        # Left wall (two segments with a gap in the middle)
        new_rectangles.append(pygame.Rect(square_x, square_y + 20, 20, gap_y_start - (square_y + 20))) # Top segment
        new_rectangles.append(pygame.Rect(square_x, gap_y_start + gap_height, 20, (square_y + square_size - 20) - (gap_y_start + gap_height))) # Bottom segment

        # Right wall (two segments with a gap in the middle)
        new_rectangles.append(pygame.Rect(square_x + square_size - 20, square_y + 20, 20, gap_y_start - (square_y + 20))) # Top segment
        new_rectangles.append(pygame.Rect(square_x + square_size - 20, gap_y_start + gap_height, 20, (square_y + square_size - 20) - (gap_y_start + gap_height))) # Bottom segment

        rectangles = new_rectangles

        # Coffee machines on top of the structure
        circles = []
        # Ensure exactly 10 coffee machines are placed
        coffee_machine_count = 10 
        padding = 20 # Padding from structure walls for placing coffee machines
        
        # Calculate inner dimensions for placing circles
        inner_width = square_size - 2 * 20 # Subtract wall thickness (20px each side)
        inner_height = square_size - 2 * 20
        inner_top_y = square_y + 20
        inner_bottom_y = square_y + square_size - 20

        # Distribute coffee machines on the top and bottom segments of the structure, 5 on top, 5 on bottom
        # Ensure even distribution and that they are placed on the structure
        for i in range(coffee_machine_count // 2):
            # Calculate x position: evenly space them across the inner width
            if coffee_machine_count // 2 > 1:
                x_pos = square_x + 20 + padding + i * (inner_width - 2 * padding) // (coffee_machine_count // 2 - 1)
            else:
                x_pos = square_x + square_size // 2 # Center if only one coffee machine

            circles.append((x_pos, inner_top_y + RUBBISH_RADIUS + 5, False)) # Top row
            circles.append((x_pos, inner_bottom_y - RUBBISH_RADIUS - 5, False)) # Bottom row

        return rectangles, circles
    except Exception as e:
        print(f"Error in setup_pantry_room: {e}")
        return [], []

def setup_secretary_room_objects(width: int, height: int) -> Tuple[pygame.Rect, Tuple[int, int], int, int]:
    """Setup secretary room objects (GDD Section 3)."""
    # Center the table in the room
    table_x = width // 2 - TABLE_WIDTH // 2
    table_y = height // 2 - TABLE_HEIGHT // 2
    secretary_table = pygame.Rect(table_x, table_y, TABLE_WIDTH, TABLE_HEIGHT)
    
    # Position secretary behind table (no chair)
    secretary_x = table_x + TABLE_WIDTH // 2
    secretary_y = table_y - SECRETARY_RADIUS - 10
    
    # Return None for chair center since we removed the chair
    return secretary_table, (0, 0), secretary_x, secretary_y

def setup_boss_room_objects(width: int, height: int) -> Tuple[int, int]:
    """Setup boss room objects (GDD Section 3)."""
    # Position boss higher in the room
    boss_x = width // 2
    boss_y = height // 3  # Moved up to 1/3 of the room height
    
    return boss_x, boss_y
