import pygame
import sys
# Import specific constants needed, excluding WIDTH and HEIGHT
from constants import BLACK, WHITE, SMALL_FONT_SIZE

def show_start_screen(screen, medium_font_obj, small_font_obj):
    """Display the start screen and wait for SPACE key (GDD Section 6).
       Accepts font objects directly."""
    # Retrieve current screen dimensions for responsiveness
    WIDTH = screen.get_width()
    HEIGHT = screen.get_height()

    instructions = [
        "Navigate Adela through a corporate nightmare to escape!",
        "Collect items, avoid traps, and solve puzzles.",
        "Use arrow keys to move, [Y]/[N] for doors,",
        "and type passwords when prompted.",
        "Beware: traps end your game!"
    ]
    # Use small_font_obj for the start prompt as per GDD
    start_text_surface = small_font_obj.render("Press [SPACE] to Start", True, WHITE)

    while True:
        screen.fill(BLACK)
        
        # Render instructions
        total_instructions_height = len(instructions) * small_font_obj.get_linesize()
        # Calculate vertical position to center the block of text
        start_y_instructions = (HEIGHT - total_instructions_height - start_text_surface.get_height() - 40) // 2

        for i, line in enumerate(instructions):
            text_surface = small_font_obj.render(line, True, WHITE)
            text_rect = text_surface.get_rect(center=(WIDTH // 2, start_y_instructions + i * small_font_obj.get_linesize()))
            screen.blit(text_surface, text_rect)
        
        # Render start prompt
        start_rect = start_text_surface.get_rect(center=(WIDTH // 2, HEIGHT - 100))
        screen.blit(start_text_surface, start_rect)
        
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return True
